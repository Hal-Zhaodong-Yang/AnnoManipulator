//
// Created by kjwang on 2020/2/19.
//
//本示例程序供大家学习probot_anno的位置及速度控制如何编程，展示了：
//1.如何使用ikfast求解器帮我们去计算机械臂逆解;
//2.如何创建位置控制数据发布者，并发布位置数据（速度控制也一样的，把名字换换而已），控制gazebo的机械臂动起来。
//
#include <ros/ros.h>
#include <iostream>
#include <time.h>
#include <cmath>
#include <Eigen/Dense>
#include "vector"
#include "std_msgs/Float64MultiArray.h"
#include "controller_manager_msgs/SwitchController.h"
#include "controller_manager_msgs/ListControllers.h"


using namespace std;
using namespace Eigen;


Matrix4d kinetic(Matrix<double, 6, 1> theta);
Matrix<double, 6, 1> revkinetic(Matrix<double, 6, 1> pos);
Matrix<double, 6, 1> pos_pos(Matrix4d t);
Matrix<double, 6, 1> pieper_thetar(Matrix<double, 6, 1> theta, Matrix4d t60);
Matrix<double, 6, 1> pieper_theta0(Matrix<double, 6, 1> theta, Matrix4d t60);
Matrix<double, 6, 1> pieper_theta1(Matrix<double, 6, 1> theta, Matrix4d t60, double t);
Matrix<double, 6, 1> pieper_t1(Matrix<double, 6, 1> theta, Matrix4d t60);
Matrix<double, 6, 1> pieper_theta2(Matrix4d t60);

Matrix<double, 6, 1> pieper_thetar(Matrix<double, 6, 1> theta, Matrix4d t60)
{
    Matrix3d r10, r21, r32,r60;
    r10 << cos(theta(0)), -sin(theta(0)), 0,
    sin(theta(0)), cos(theta(0)), 0,
    0, 0, 1;
    r21 <<  -sin(theta(1)), -cos(theta(1)), 0,
    0, 0, -1,
    cos(theta(1)), -sin(theta(1)), 0;
    r32 << cos(theta(2)), -sin(theta(2)), 0,
    sin(theta(2)), cos(theta(2)), 0,
    0, 0, 1;
    for(int i = 0;i <= 2;i ++){
        for(int j = 0;j <= 2;j ++){
            r60(i, j) = t60(i,j);
        }
    }
    Matrix3d r43_0, r40_0, r64_0;
    r43_0 << 1, 0, 0,
    0, 0, -1,
    0, 1, 0;
    r40_0 = r10 * r21 * r32 * r43_0;
    r64_0 = r40_0.inverse() * r60;

    Matrix3d r46_000,r66_0;
    r46_000 << 0, 0, 1,
    0, 1, 0,
    -1, 0, 0;
    r66_0 = r46_000 * r64_0;
    theta(4) = atan2(r66_0(0, 2), sqrt(r66_0(1, 2) * r66_0(1, 2) + r66_0(2, 2) * r66_0(2, 2)));
    if(theta(4) <= 0){
        theta(4) = -theta(4);
    }
    theta(3) = atan2(-r66_0(1, 2) / cos(theta(4)), r66_0(2, 2) / cos(theta(4)));
    theta(5) = atan2(-r66_0(0, 1) / cos(theta(4)), r66_0(0, 0) / cos(theta(4)));

    MatrixXd nosol(6, 1);
    nosol << 200, 0, 0, 0, 0, 0;

    Matrix4d t76,t70;
    t76 << 1, 0, 0, 0,
    0, 0, 1, 0,
    0, -1, 0, 0.055,
    0, 0, 0, 1;
    t70 = t60 * t76;

    Matrix<double, 6, 1> position, position_sol;

    position = pos_pos(t70);

    MatrixXd ev(6, 1);
    double e;


    if(isnan(theta(0)) || isnan(theta(1)) || isnan(theta(2)) || isnan(theta(3)) || isnan(theta(4)) || isnan(theta(5))){
        return nosol;
    }else{
        position_sol = pos_pos(kinetic(theta));
        ev = position - position_sol;
        e = sqrt(ev(0) * ev(0) + ev(1) * ev(1) + ev(2) * ev(2) + ev(3) * ev(3) + ev(4) * ev(4) + ev(5) * ev(5));
        if(e >= 0.01){
            return nosol;
        }else return theta;

    }



}



Matrix<double, 6, 1> pieper_theta0(Matrix<double, 6, 1> theta, Matrix4d t60)
{
    double f1, f2;
    f1 = 0.2289 * sin(theta(2)) + 0.225;
    f2 = -0.2289 * cos(theta(2)); 
    Matrix<double, 6, 1> theta1;
    theta1 = theta;
    theta(0) = acos(t60(0,3) / (-sin(theta(1)) * f1 - cos(theta(1)) * f2));
    theta(0) = floor(theta(0) * 1000000000.0 + 0.5) / 1000000000.0;
    theta1(0) = -theta(0);

    Matrix<double, 6, 1> sol1, sol2;
    sol1 = pieper_thetar(theta, t60);
    sol2 = pieper_thetar(theta1, t60);
    MatrixXd nosol(6, 1);
    nosol << 200, 0, 0, 0, 0, 0;
    if(sol1(0) <= 100) return sol1;
    else if(sol2(0) <= 100) return sol2;
    else return nosol;

}



Matrix<double, 6, 1> pieper_theta1(Matrix<double, 6, 1> theta, Matrix4d t60, double t)
{
    Matrix<double, 6, 1> theta1;
    theta1 = theta;
    theta(1) = atan(t);
    if(theta(1) >= 1.1316){
        theta1(1) = theta(1) - 3.14159265;
    }else if(theta(1) <= -1.1316){
        theta1(1) = theta(1) + 3.14159265;
    }else {
        theta1(1) = theta(1);
    }
    theta(1) = floor(theta(1) * 1000000000.0 + 0.5) / 1000000000.0;
    theta1(1) = floor(theta1(1) * 1000000000.0 + 0.5) / 1000000000.0;

    Matrix<double, 6, 1> sol1, sol2;
    sol1 = pieper_theta0(theta, t60);
    sol2 = pieper_theta0(theta1, t60);
    MatrixXd nosol(6, 1);
    nosol << 200, 0, 0, 0, 0, 0;
    if(sol1(0) <= 100) return sol1;
    else if(sol2(0) <= 100) return sol2;
    else return nosol;

}


Matrix<double, 6, 1> pieper_t1(Matrix<double, 6, 1> theta, Matrix4d t60)
{
    double f1, f2;
    f1 = 0.2289 * sin(theta(2)) + 0.225;
    f2 = -0.2289 * cos(theta(2)); 
    double t1,t2;
    t1 = (2 * f1 * f2 - sqrt(4 * f1 * f1 * f2 *f2 - 4 * (f2 * f2 - t60(2, 3) * t60(2, 3)) * (f1 * f1 - t60(2, 3) * t60(2, 3)))) / (2 * (f2 * f2 - t60(2, 3) * t60(2, 3)));
    t2 = (2 * f1 * f2 + sqrt(4 * f1 * f1 * f2 *f2 - 4 * (f2 * f2 - t60(2, 3) * t60(2, 3)) * (f1 * f1 - t60(2, 3) * t60(2, 3)))) / (2 * (f2 * f2 - t60(2, 3) * t60(2, 3)));
    
    Matrix<double, 6, 1> sol1, sol2;
    sol1 = pieper_theta1(theta, t60, t1);
    sol2 = pieper_theta1(theta, t60, t2);
    MatrixXd nosol(6, 1);
    nosol << 200, 0, 0, 0, 0, 0;
    if(sol1(0) <= 100) return sol1;
    else if(sol2(0) <= 100) return sol2;
    else return nosol;

}

Matrix<double, 6, 1> pieper_theta2(Matrix4d t60)
{
    Matrix<double, 6, 1> theta, theta1;
    Matrix<double, 6, 1> sol1, sol2;
    theta << 0, 0, 0, 0, 0, 0;
    theta1 << 0, 0, 0, 0, 0, 0;
    double r = t60(0, 3) * t60(0, 3) + t60(1, 3) * t60(1, 3) + t60(2, 3) *t60(2, 3);
    theta(2) = asin((r - 0.2289 * 0.2289 - 0.225 * 0.225)/(2 * 0.2289 * 0.225));
    if(theta(2) >= 0){
        theta1(2) = 3.14159265 - theta(2);
    }else{
        theta1(2) = theta(2);
    }

    theta(2) = floor(theta(2) * 1000000000.0 + 0.5) / 1000000000.0;
    theta1(2) = floor(theta1(2) * 1000000000.0 + 0.5) / 1000000000.0;

    sol1 = pieper_t1(theta, t60);
    sol2 = pieper_t1(theta1, t60);
    MatrixXd nosol(6, 1);
    nosol << 200, 0, 0, 0, 0, 0;
    if(sol1(0) <= 100) return sol1;
    else if(sol2(0) <= 100) return sol2;
    else return nosol;


}

Matrix<double, 6, 1> revkinetic(Matrix<double, 6, 1> pos)
{
    Matrix4d t70;
    t70(0,3) = pos(0);
    t70(1,3) = pos(1);
    t70(2,3) = pos(2);
    t70(3,3) = 1;
    t70(3,0) = 0;
    t70(3,1) = 0;
    t70(3,2) = 0;
    Matrix3d rotx, roty, rotz;
    rotx << 1, 0, 0,
    0, cos(pos(3)), -sin(pos(3)),
    0, sin(pos(3)), cos(pos(3));
    roty << cos(pos(4)), 0, sin(pos(4)),
    0, 1, 0,
    -sin(pos(4)), 0, cos(pos(4));
    rotz << cos(pos(5)), -sin(pos(5)), 0,
    sin(pos(5)), cos(pos(5)), 0,
    0, 0, 1;
    Matrix3d rot = rotz * roty * rotx;
    for(int i = 0;i <= 2;i ++){
        for(int j = 0;j <= 2;j ++){
            t70(i,j) = rot(i,j);
        }
    }

    Matrix4d t67;
    t67 << 1, 0, 0, 0,
    0, 0, -1, 0.055,
    0, 1, 0, 0,
    0, 0, 0, 1;
    Matrix4d t60 = t70 * t67;

    //cout <<"t60 "<<endl  << t60 << endl << endl;

    //pieper

    return pieper_theta2(t60);

}


Matrix4d kinetic(Matrix<double, 6, 1> theta)
{
    Matrix4d t10, t21, t32, t43, t54, t65; //
    t10 << cos(theta(0)), -sin(theta(0)), 0, 0,
    sin(theta(0)), cos(theta(0)), 0, 0,
    0, 0, 1, 0,
    0, 0, 0, 1;
    t21 <<  -sin(theta(1)), -cos(theta(1)), 0, 0,
    0, 0, -1, 0,
    cos(theta(1)), -sin(theta(1)), 0, 0,
    0, 0, 0, 1;
    t32 << cos(theta(2)), -sin(theta(2)), 0, 0.225,
    sin(theta(2)), cos(theta(2)), 0, 0,
    0, 0, 1, 0,
    0, 0, 0, 1;
    t43 << cos(theta(3)), -sin(theta(3)), 0, 0,
    0, 0, -1, -0.2289,
    sin(theta(3)), cos(theta(3)), 0, 0,
    0, 0, 0, 1;
    t54 << sin(theta(4)), cos(theta(4)), 0, 0,
    0, 0, 1, 0,
    cos(theta(4)), -sin(theta(4)), 0, 0,
    0, 0, 0, 1;
    t65 << cos(theta(5)), -sin(theta(5)), 0, 0,
    0, 0, -1, 0,
    sin(theta(5)), cos(theta(5)),0, 0,
    0, 0, 0, 1;
    Matrix4d t76;
    t76 << 1, 0, 0, 0,
    0, 0, 1, 0,
    0, -1, 0, 0.055,
    0, 0, 0, 1;
    //test
    /*Matrix4d t60;
    t60 =   t10 * t21 * t32 * t43 * t54 * t65;
    cout << "kinetic t60" << endl << t60 << endl;*/
    Matrix4d t70 = t10 * t21 * t32 * t43 * t54 * t65 * t76;

    return t70;

}



Matrix<double, 6, 1> pos_pos(Matrix4d t)
{
    MatrixXd pos(6,1);
    pos(0) = t(0,3);
    pos(1) = t(1,3);
    pos(2) = t(2,3);
    pos(4) = atan2(-t(2,0),sqrt(t(0,0) * t(0,0) + t(1,0) * t(1, 0)));
    pos(5) = atan2(t(1,0)/cos(pos(4)),t(0,0)/cos(pos(4)));
    pos(3) = atan2(t(2,1)/cos(pos(4)), t(2,2)/cos(pos(4)));

    return pos;
}





int main(int argc, char **argv) 
{
    //节点初始化
    ros::init(argc, argv, "control_example");
    //创建节点句柄对象
    ros::NodeHandle node_handle;
    
    ros::Publisher pos_pub = node_handle.advertise<std_msgs::Float64MultiArray>("/probot_anno/arm_pos_controller/command", 100);
    
    int looptimes = 10;
    ros::Rate loop_rate(looptimes);
    while(ros::ok())
    {
        MatrixXd pos(6, 1);
        pos << 0.2289, 0, 0.454, 0.785, -0.785, 0;
        //cin >> pos(0) >> pos(1) >> pos(2) >> pos(3) >> pos(4) >> pos(5);
        cin  >> pos(3) >> pos(4) >> pos(5);
        pos(2) -= 0.284;
        //初始化publish的变量并初始化6个值
        MatrixXd joint(6, 1);
        joint = revkinetic(pos);
        
        std_msgs::Float64MultiArray init_pos;
        init_pos.data.push_back(0);
        init_pos.data.push_back(0);
        init_pos.data.push_back(0);
        init_pos.data.push_back(0);
        init_pos.data.push_back(0);
        init_pos.data.push_back(0);
        //double targetPose[6] = {0.1, 0.1, 0.1, 0.1, 0.1, 0.1};//运动的起点位置
        //double targetPose[6] = {0, -1.5708, 1.5708, 0, 1.5708, 0};//运动的起点位置

        //为要发送的变量装入解出的六关节坐标
        //如果是要发送速度，那也是类似于这样，装入6个关节角速度值（弧度制）即可
        init_pos.data.at(0) = joint(0);
        init_pos.data.at(1) = joint(1);
        init_pos.data.at(2) = joint(2);
        init_pos.data.at(3) = joint(3);
        init_pos.data.at(4) = joint(4);
        init_pos.data.at(5) = joint(5);

        //发送出去，若成功，机械臂状态会改变
        pos_pub.publish(init_pos);

        loop_rate.sleep();

    }
}
