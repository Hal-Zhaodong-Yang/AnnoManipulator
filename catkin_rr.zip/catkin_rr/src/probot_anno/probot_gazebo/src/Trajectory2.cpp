int isStart;
double start;

int n = 3;//4 points,3 traj


#include "Trajectory.h"
Eigen::VectorXd thetax(6);
using namespace std;

int main(int argc, char **argv) {
    bool ret;
    //节点初始化
    ros::init(argc, argv, "control_example");
    //创建节点句柄对象
    ros::NodeHandle node_handle;
    ros::AsyncSpinner spinner(1);
    ROS_INFO_STREAM("start");
    sleep(5);
    //创建发布者对象，用于发布位置信息，
    //位置控制的话题名为："/probot_anno/arm_pos_controller/command"
    //速度控制的话题名为："/probot_anno/arm_vel_controller/command"
    //发送的数据类型均为：std_msgs::Float64MultiArray，
    //它的创建与赋值方法在下面有，一组6个浮点数
    ros::Publisher vel_pub = node_handle.advertise<std_msgs::Float32MultiArray>("speed_chatter", 1000);

    double t0 = 0,t = 0,tf = 10;
    struct timeval start, current;
    double begin = 0,tmp = 0;
    double speed[6];
    int count = 0;

    std_msgs::Float32MultiArray vel_output;
    vel_output.data.push_back(0);
    vel_output.data.push_back(0);
    vel_output.data.push_back(0);
    vel_output.data.push_back(0);
    vel_output.data.push_back(0);
    vel_output.data.push_back(0);

    Set_Param();
    Solve_Route(tf);
    while (t0 <= 3*tf) {
        if(!isStart){
            //gettimeofday(&start, NULL);
            //begin = start.tv_sec + double(start.tv_usec) / 1e6;
            //while (ros::Time::now().toSec()<0.001);
            begin = ros::Time::now().toSec();
            isStart = 1;
            thetax << 0,0,0,0,0,0;
        }
        //gettimeofday(&current, NULL);
        //double current_t1 = current.tv_sec + double(current.tv_usec) / 1e6;
        double current_t1 = ros::Time::now().toSec();
        t0 = current_t1 - begin;
        cout<<t0<<endl;
        cout << "rostime" << endl << ros::Time::now().toSec() << endl;

        if (t0 >= 0 && t0 < tf) {
            t = t0;
            for (int i = 0; i < 6; i++)
                speed[i] = a1(0, i) + 2 * a2(0, i) * t + 3 * a3(0, i) * pow(t, 2) + 4 * a4(0, i) * pow(t, 3) +
                       5 * a5(0, i) * pow(t, 4);
        } else if (t0 >= tf && t0 < 2*tf) {
            t = t0 - tf;
            for (int i = 0; i < 6; i++)
                speed[i] = a1(1, i) + 2 * a2(1, i) * t + 3 * a3(1, i) * pow(t, 2) + 4 * a4(1, i) * pow(t, 3) +
                       5 * a5(1, i) * pow(t, 4);
        } else if (t0 >= 2 * tf && t0 <= 3 * tf) {
            t = t0 - 2 * tf;
            for (int i = 0; i < 6; i++)
                speed[i] = a1(2, i) + 2 * a2(2, i) * t + 3 * a3(2, i) * pow(t, 2) + 4 * a4(2, i) * pow(t, 3) +
                       5 * a5(2, i) * pow(t, 4);
        } else {
            for (int i = 0; i < 6; i++)
                speed[i] = 0;
        }
        vel_output.data.at(0) = speed[0] * 30 * 180 / 3.1415926535897;
        vel_output.data.at(1) = speed[1] * 205 * 180 / 3.1415926535897 / 3;
        vel_output.data.at(2) = speed[2] * 50 * 180 / 3.1415926535897;
        vel_output.data.at(3) = speed[3] * 125 * 180 / 3.1415926535897 / 2;
        vel_output.data.at(4) = speed[4] * 125 * 180 / 3.1415926535897 / 2;
        vel_output.data.at(5) = speed[5] * 200 * 180 / 3.1415926535897 / 9;

        for (int (j) = 0; (j) < 6; ++(j)) {
            if(speed[j]>0.4||speed[j]<-0.4){
                count++;
                break;
            }
        }
        //cout<<speed<<endl;
        tmp = t0;
        //cout<<Kine(thetax)<<endl;
        vel_pub.publish(vel_output);
        cout << "speed" << endl << speed[0] << endl;
        ROS_INFO_STREAM("published");
    }
    for(int i = 0; i < 6; i++){
        vel_output.data.at(i) = 0;
        // thetax(i) = thetax(i) + speed[i]*(t0-tmp);
    }
    //cout<<speed<<endl;
    tmp = t0;
    //cout<<Kine(thetax)<<endl;
    //cout<<count<<endl;
    vel_pub.publish(vel_output);
    ROS_INFO_STREAM("published");
}