#include<ros/ros.h>
#include "std_msgs/Float32MultiArray.h"
#include "controller_manager_msgs/SwitchController.h"
#include "controller_manager_msgs/ListControllers.h"
#include <iostream>
#include<cmath>
#include <Eigen/Dense>

#define PI 3.1415926

using namespace Eigen;
using namespace std;

Matrix4d kinetic(Matrix<double, 6, 1> theta);
Matrix<double, 6, 1> revkinetic(Matrix<double, 6, 1> pos);
Matrix<double, 6, 1> pos_pos(Matrix4d t);
Matrix<double, 6, 1> pieper_thetar(Matrix<double, 6, 1> theta, Matrix4d t60);
Matrix<double, 6, 1> pieper_theta0(Matrix<double, 6, 1> theta, Matrix4d t60);
Matrix<double, 6, 1> pieper_theta1(Matrix<double, 6, 1> theta, Matrix4d t60, double t);
Matrix<double, 6, 1> pieper_t1(Matrix<double, 6, 1> theta, Matrix4d t60);
Matrix<double, 6, 1> pieper_theta2(Matrix4d t60);

Matrix<double, 6, 1> pieper_thetar(Matrix<double, 6, 1> theta, Matrix4d t60)
{
    Matrix3d r10, r21, r32,r60;
    r10 << cos(theta(0)), -sin(theta(0)), 0,
    sin(theta(0)), cos(theta(0)), 0,
    0, 0, 1;
    r21 <<  -sin(theta(1)), -cos(theta(1)), 0,
    0, 0, -1,
    cos(theta(1)), -sin(theta(1)), 0;
    r32 << cos(theta(2)), -sin(theta(2)), 0,
    sin(theta(2)), cos(theta(2)), 0,
    0, 0, 1;
    for(int i = 0;i <= 2;i ++){
        for(int j = 0;j <= 2;j ++){
            r60(i, j) = t60(i,j);
        }
    }
    Matrix3d r43_0, r40_0, r64_0;
    r43_0 << 1, 0, 0,
    0, 0, -1,
    0, 1, 0;
    r40_0 = r10 * r21 * r32 * r43_0;
    r64_0 = r40_0.inverse() * r60;

    Matrix3d r46_000,r66_0;
    r46_000 << 0, 0, 1,
    0, 1, 0,
    -1, 0, 0;
    r66_0 = r46_000 * r64_0;
    theta(4) = atan2(r66_0(0, 2), sqrt(r66_0(1, 2) * r66_0(1, 2) + r66_0(2, 2) * r66_0(2, 2)));
    if(theta(4) <= 0){
        theta(4) = -theta(4);
    }
    theta(3) = atan2(-r66_0(1, 2) / cos(theta(4)), r66_0(2, 2) / cos(theta(4)));
    theta(5) = atan2(-r66_0(0, 1) / cos(theta(4)), r66_0(0, 0) / cos(theta(4)));

    MatrixXd nosol(6, 1);
    nosol << 200, 0, 0, 0, 0, 0;

    Matrix4d t76,t70;
    t76 << 1, 0, 0, 0,
    0, 0, 1, 0,
    0, -1, 0, 0.055,
    0, 0, 0, 1;
    t70 = t60 * t76;

    Matrix<double, 6, 1> position, position_sol;

    position = pos_pos(t70);

    MatrixXd ev(6, 1);
    double e;


    if(isnan(theta(0)) || isnan(theta(1)) || isnan(theta(2)) || isnan(theta(3)) || isnan(theta(4)) || isnan(theta(5))){
        return nosol;
    }else{
        position_sol = pos_pos(kinetic(theta));
        ev = position - position_sol;
        e = sqrt(ev(0) * ev(0) + ev(1) * ev(1) + ev(2) * ev(2) + ev(3) * ev(3) + ev(4) * ev(4) + ev(5) * ev(5));
        if(e >= 0.01){
            return nosol;
        }else return theta;

    }



}



Matrix<double, 6, 1> pieper_theta0(Matrix<double, 6, 1> theta, Matrix4d t60)
{
    double f1, f2;
    f1 = 0.2289 * sin(theta(2)) + 0.225;
    f2 = -0.2289 * cos(theta(2)); 
    Matrix<double, 6, 1> theta1;
    theta1 = theta;
    theta(0) = acos(t60(0,3) / (-sin(theta(1)) * f1 - cos(theta(1)) * f2));
    theta(0) = floor(theta(0) * 1000000000.0 + 0.5) / 1000000000.0;
    theta1(0) = -theta(0);

    Matrix<double, 6, 1> sol1, sol2;
    sol1 = pieper_thetar(theta, t60);
    sol2 = pieper_thetar(theta1, t60);
    MatrixXd nosol(6, 1);
    nosol << 200, 0, 0, 0, 0, 0;
    if(sol1(0) <= 100) return sol1;
    else if(sol2(0) <= 100) return sol2;
    else return nosol;

}



Matrix<double, 6, 1> pieper_theta1(Matrix<double, 6, 1> theta, Matrix4d t60, double t)
{
    Matrix<double, 6, 1> theta1;
    theta1 = theta;
    theta(1) = atan(t);
    if(theta(1) >= 1.1316){
        theta1(1) = theta(1) - 3.14159265;
    }else if(theta(1) <= -1.1316){
        theta1(1) = theta(1) + 3.14159265;
    }else {
        theta1(1) = theta(1);
    }
    theta(1) = floor(theta(1) * 1000000000.0 + 0.5) / 1000000000.0;
    theta1(1) = floor(theta1(1) * 1000000000.0 + 0.5) / 1000000000.0;

    Matrix<double, 6, 1> sol1, sol2;
    sol1 = pieper_theta0(theta, t60);
    sol2 = pieper_theta0(theta1, t60);
    MatrixXd nosol(6, 1);
    nosol << 200, 0, 0, 0, 0, 0;
    if(sol1(0) <= 100) return sol1;
    else if(sol2(0) <= 100) return sol2;
    else return nosol;

}


Matrix<double, 6, 1> pieper_t1(Matrix<double, 6, 1> theta, Matrix4d t60)
{
    double f1, f2;
    f1 = 0.2289 * sin(theta(2)) + 0.225;
    f2 = -0.2289 * cos(theta(2)); 
    double t1,t2;
    t1 = (2 * f1 * f2 - sqrt(4 * f1 * f1 * f2 *f2 - 4 * (f2 * f2 - t60(2, 3) * t60(2, 3)) * (f1 * f1 - t60(2, 3) * t60(2, 3)))) / (2 * (f2 * f2 - t60(2, 3) * t60(2, 3)));
    t2 = (2 * f1 * f2 + sqrt(4 * f1 * f1 * f2 *f2 - 4 * (f2 * f2 - t60(2, 3) * t60(2, 3)) * (f1 * f1 - t60(2, 3) * t60(2, 3)))) / (2 * (f2 * f2 - t60(2, 3) * t60(2, 3)));
    
    Matrix<double, 6, 1> sol1, sol2;
    sol1 = pieper_theta1(theta, t60, t1);
    sol2 = pieper_theta1(theta, t60, t2);
    MatrixXd nosol(6, 1);
    nosol << 200, 0, 0, 0, 0, 0;
    if(sol1(0) <= 100) return sol1;
    else if(sol2(0) <= 100) return sol2;
    else return nosol;

}

Matrix<double, 6, 1> pieper_theta2(Matrix4d t60)
{
    Matrix<double, 6, 1> theta, theta1;
    Matrix<double, 6, 1> sol1, sol2;
    theta << 0, 0, 0, 0, 0, 0;
    theta1 << 0, 0, 0, 0, 0, 0;
    double r = t60(0, 3) * t60(0, 3) + t60(1, 3) * t60(1, 3) + t60(2, 3) *t60(2, 3);
    theta(2) = asin((r - 0.2289 * 0.2289 - 0.225 * 0.225)/(2 * 0.2289 * 0.225));
    if(theta(2) >= 0){
        theta1(2) = 3.14159265 - theta(2);
    }else{
        theta1(2) = theta(2);
    }

    theta(2) = floor(theta(2) * 1000000000.0 + 0.5) / 1000000000.0;
    theta1(2) = floor(theta1(2) * 1000000000.0 + 0.5) / 1000000000.0;

    sol1 = pieper_t1(theta, t60);
    sol2 = pieper_t1(theta1, t60);
    MatrixXd nosol(6, 1);
    nosol << 200, 0, 0, 0, 0, 0;
    if(sol1(0) <= 100) return sol1;
    else if(sol2(0) <= 100) return sol2;
    else return nosol;


}

Matrix<double, 6, 1> revkinetic(Matrix<double, 6, 1> pos)
{
    Matrix4d t70;
    t70(0,3) = pos(0);
    t70(1,3) = pos(1);
    t70(2,3) = pos(2);
    t70(3,3) = 1;
    t70(3,0) = 0;
    t70(3,1) = 0;
    t70(3,2) = 0;
    Matrix3d rotx, roty, rotz;
    rotx << 1, 0, 0,
    0, cos(pos(3)), -sin(pos(3)),
    0, sin(pos(3)), cos(pos(3));
    roty << cos(pos(4)), 0, sin(pos(4)),
    0, 1, 0,
    -sin(pos(4)), 0, cos(pos(4));
    rotz << cos(pos(5)), -sin(pos(5)), 0,
    sin(pos(5)), cos(pos(5)), 0,
    0, 0, 1;
    Matrix3d rot = rotz * roty * rotx;
    for(int i = 0;i <= 2;i ++){
        for(int j = 0;j <= 2;j ++){
            t70(i,j) = rot(i,j);
        }
    }

    Matrix4d t67;
    t67 << 1, 0, 0, 0,
    0, 0, -1, 0.055,
    0, 1, 0, 0,
    0, 0, 0, 1;
    Matrix4d t60 = t70 * t67;

    cout <<"t60 "<<endl  << t60 << endl << endl;

    //pieper

    return pieper_theta2(t60);

}


Matrix4d kinetic(Matrix<double, 6, 1> theta)
{
    Matrix4d t10, t21, t32, t43, t54, t65; //
    t10 << cos(theta(0)), -sin(theta(0)), 0, 0,
    sin(theta(0)), cos(theta(0)), 0, 0,
    0, 0, 1, 0,
    0, 0, 0, 1;
    t21 <<  -sin(theta(1)), -cos(theta(1)), 0, 0,
    0, 0, -1, 0,
    cos(theta(1)), -sin(theta(1)), 0, 0,
    0, 0, 0, 1;
    t32 << cos(theta(2)), -sin(theta(2)), 0, 0.225,
    sin(theta(2)), cos(theta(2)), 0, 0,
    0, 0, 1, 0,
    0, 0, 0, 1;
    t43 << cos(theta(3)), -sin(theta(3)), 0, 0,
    0, 0, -1, -0.2289,
    sin(theta(3)), cos(theta(3)), 0, 0,
    0, 0, 0, 1;
    t54 << sin(theta(4)), cos(theta(4)), 0, 0,
    0, 0, 1, 0,
    cos(theta(4)), -sin(theta(4)), 0, 0,
    0, 0, 0, 1;
    t65 << cos(theta(5)), -sin(theta(5)), 0, 0,
    0, 0, -1, 0,
    sin(theta(5)), cos(theta(5)),0, 0,
    0, 0, 0, 1;
    Matrix4d t76;
    t76 << 1, 0, 0, 0,
    0, 0, 1, 0,
    0, -1, 0, 0.055,
    0, 0, 0, 1;
    //test
    /*Matrix4d t60;
    t60 =   t10 * t21 * t32 * t43 * t54 * t65;
    cout << "kinetic t60" << endl << t60 << endl;*/
    Matrix4d t70 = t10 * t21 * t32 * t43 * t54 * t65 * t76;

    return t70;

}



Matrix<double, 6, 1> pos_pos(Matrix4d t)
{
    MatrixXd pos(6,1);
    pos(0) = t(0,3);
    pos(1) = t(1,3);
    pos(2) = t(2,3);
    pos(4) = atan2(-t(2,0),sqrt(t(0,0) * t(0,0) + t(1,0) * t(1, 0)));
    pos(5) = atan2(t(1,0)/cos(pos(4)),t(0,0)/cos(pos(4)));
    pos(3) = atan2(t(2,1)/cos(pos(4)), t(2,2)/cos(pos(4)));

    return pos;
}

int main(int argc, char ** argv)
{
    //Matrix<double, 6, 1> pos0,pos1,pos2;
    MatrixXd joint_ang(6,3);

    //cout << "joint_ang"<< joint_ang << endl;

    double dur;
    double a[6][2], b[6][4];

    MatrixXd estimate(6, 3);

    MatrixXd joint_vel(6, 2);
    MatrixXd joint_acc(6, 2);
    joint_vel << 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0;
    joint_acc << 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0;

   /* joint_vel(3, 1) = 0;
    joint_vel(3, 2) = 0;
    joint_acc(3, 1) = 0;
    joint_acc(3, 2) = 0;
    joint_vel(5, 1) = 0;
    joint_vel(5, 2) = 0;
    joint_acc(5, 1) = 0;
    joint_acc(5, 2) = 0;*/

    //cout << "joint_vel" << endl << joint_vel << endl;
    //cout << "joint_acc" << endl << joint_acc << endl;

    Matrix<double, 6, 6> coe;

    //cout << "coe" << endl << coe << endl;
    

   // cout << "coe" << endl << coe << endl << "coe2" << endl << coe2 << endl << "coe3" << endl <<  coe3 << endl;

    ros::init(argc, argv, "jacob");

    ros::NodeHandle vel_control;

    ros::Publisher vel_pub = vel_control.advertise<std_msgs::Float32MultiArray>("speed_chatter", 1000);

    int looptimes = 200;
    ros::Rate loop_rate(looptimes);

    int count = -1;
    int flag = 0;
    int ring_time = 0;
    double interval = 0;
/*
    double timeseq[100];
    int whichtime = 0;
    timeseq[0] = 5;
    timeseq[1] = 5;
    timeseq[2] = 5;
    timeseq[3] = 6;

    timeseq[4] = 5;
    timeseq[5] = 6;
    timeseq[6] = 5;
    timeseq[7] = 6;

    timeseq[8] = 5;
    timeseq[9] = 6;
    timeseq[10] = 5;
    timeseq[11] = 6;

    timeseq[12] = 5;
    timeseq[13] = 6;
    timeseq[14] = 5;
    timeseq[15] = 6;

    timeseq[16] = 5;
    timeseq[17] = 6;
    timeseq[18] = 5;
    timeseq[19] = 9;

    dur = 6;

    Matrix<double, 6, 1> joint_velr;
    joint_velr << 0, 0, 0, 0, 0, 0;
    Matrix<double, 6, 1> postemp;
    vector< Matrix<double,6, 1> > traj;
*/
    /*postemp <<0.32, 0, 0.15, 1.57, 0, 0;
    traj.push_back(postemp);
    postemp <<0.2, -0.2, -0.05, 1.57, 0, 0;
    traj.push_back(postemp);
    postemp <<0.38, 0, 0.15, 1.57, 0, 0;
    traj.push_back(postemp);
    postemp <<0.2, 0.15, -0.02, 1.57, 0, 0;
    traj.push_back(postemp);

    postemp <<0.32, 0, 0.15, 1.57, 0, 0;
    traj.push_back(postemp);
    postemp <<0.22, -0.22, -0.05, 1.57, 0, 0;
    traj.push_back(postemp);
    postemp <<0.38, 0.05, 0.15, 1.57, 0, 0;
    traj.push_back(postemp);
    postemp <<0.2, 0.15, 0, 1.57, 0, 0;
    traj.push_back(postemp);

    postemp <<0.32, 0, 0.15, 1.57, 0, 0;
    traj.push_back(postemp);
    postemp <<0.22, -0.22, 0, 1.57, 0, 0;
    traj.push_back(postemp);
    postemp <<0.4, 0.05, 0.15, 1.57, 0, 0;
    traj.push_back(postemp);
    postemp <<0.23, 0.15, 0, 1.57, 0, 0;
    traj.push_back(postemp);*/

    /*

    postemp <<0.26, 0.15, 0.07, 1.57, 0, 0;
    traj.push_back(postemp);
    postemp <<0.27, 0.065, 0.30, 1.57, 0, 0;
    traj.push_back(postemp);
    postemp <<0.27, -0.15, 0.30, 1.57, 0, 0;
    traj.push_back(postemp);

    postemp <<0.28, -0.24, 0.08, 1.57, 0, 0;
    traj.push_back(postemp);
    postemp <<0.27, -0.15, 0.30, 1.57, 0, 0;
    traj.push_back(postemp);
    postemp <<0.27, 0.065, 0.30, 1.57, 0, 0;
    traj.push_back(postemp);

    /*postemp <<0.2289, 0, 0.454, 1.57, 0, 0;
    traj.push_back(postemp);*/
    /*
    postemp <<0.26, 0.15, 0.07, 1.57, 0, 0;
    traj.push_back(postemp);
    postemp <<0.27, 0.065, 0.30, 1.57, 0, 0;
    traj.push_back(postemp);
    postemp <<0.27, -0.15, 0.30, 1.57, 0, 0;
    traj.push_back(postemp);

    postemp <<0.28, -0.24, 0.08, 1.57, 0, 0;
    traj.push_back(postemp);
    postemp <<0.27, -0.15, 0.30, 1.57, 0, 0;
    traj.push_back(postemp);
    postemp <<0.27, 0.065, 0.30, 1.57, 0, 0;
    traj.push_back(postemp);
    postemp <<0.26, 0.15, 0.07, 1.57, 0, 0;
    traj.push_back(postemp);
    postemp <<0.2289, 0, 0.454, 1.57, 0, 0;
    traj.push_back(postemp);
    cout << "angle pos"<< endl << postemp(0) << endl;
    */


    Matrix<double,6,1> pos1,pos2,pos3,pos4;
    pos1 << 0.26, 0.15, 0.08, 1.57, 0, 0;
    pos2 << 0.27, 0.065, 0.30, 1.57, 0, 0;
    pos3 << 0.27, -0.15, 0.30, 1.57, 0, 0;
    pos4 << 0.28, -0.24, 0.08, 1.57, 0, 0;
    Matrix<double,6,1> angle1,angle2,angle3,angle4;

    pos1(2) -= 0.284;
    pos2(2) -= 0.284;
    pos3(2) -= 0.284;
    pos4(2) -= 0.284;

    angle1 = revkinetic(pos1);
    angle2 = revkinetic(pos2);
    angle3 = revkinetic(pos3);
    angle4 = revkinetic(pos4);

    for (int i = 0; i < 6; i++)
	{
		a[i][1] = -2 * angle1(i,0) / pow(3, 3);
		a[i][0] = 3 * angle1(i,0) / pow(3, 2);
	}

    for (int i = 0; i < 6; i++)
	{
		b[i][3] = -0.0078125 * (angle2(i,0) - angle1(i,0)) + 0.0078125 * (angle3(i,0) - angle1(i,0)) - 0.00376 * (angle4(i,0) - angle1(i,0));
		b[i][2] = 0.125 * (angle2(i,0) - angle1(i,0)) - 0.109375 * (angle3(i,0) - angle1(i,0)) + 0.04861 * (angle4(i,0) - angle1(i,0));
		b[i][1] = -0.65625 * (angle2(i,0) - angle1(i,0)) + 0.46875 * (angle3(i,0) - angle1(i,0)) - 0.18634 * (angle4(i,0) - angle1(i,0));
		b[i][0] = 1.125 * (angle2(i,0) - angle1(i,0)) - 0.5625 * (angle3(i,0) - angle1(i,0)) + 0.20833 * (angle4(i,0) - angle1(i,0));
	}

    std_msgs::Float32MultiArray vel_msg;
    vel_msg.data.push_back(0);
    vel_msg.data.push_back(0);
    vel_msg.data.push_back(0);
    vel_msg.data.push_back(0);
    vel_msg.data.push_back(0);
    vel_msg.data.push_back(0);

    int temp_int;

    while(ros::ok())
    { 
        /*
        vel_msg.data.at(0) = joint_velr(0) * 30 * 180 / 3.1415926535897;
        vel_msg.data.at(1) = joint_velr(1) * 205 * 180 / 3.1415926535897 / 3;
        vel_msg.data.at(2) = joint_velr(2) * 50 * 180 / 3.1415926535897;
        vel_msg.data.at(3) = joint_velr(3) * 125 * 180 / 3.1415926535897 / 2;
        vel_msg.data.at(4) = joint_velr(4) * 125 * 180 / 3.1415926535897 / 2;
        vel_msg.data.at(5) = joint_velr(5) * 200 * 180 / 3.1415926535897 / 9;
        */

        if(count <= 3 * looptimes && count >= 0){
            interval = 1.0 * count / looptimes;
            vel_msg.data.at(0) = (3 * a[0][1] * pow(interval, 2) + 2 * a[0][0] * interval) * 30 * 180 / PI;
            vel_msg.data.at(1) = (3 * a[1][1] * pow(interval, 2) + 2 * a[1][0] * interval - 0.0004 * interval) * 205 * 180 / (3 * PI);
            vel_msg.data.at(2) = (3 * a[2][1] * pow(interval, 2) + 2 * a[2][0] * interval) * 50 * 180 / PI;
            vel_msg.data.at(3) = (3 * a[3][1] * pow(interval, 2) + 2 * a[3][0] * interval) * 125 * 180 / (2 * PI);
            vel_msg.data.at(4) = (3 * a[4][1] * pow(interval, 2) + 2 * a[4][0] * interval) * 125 * 180 / (2 * PI);
            vel_msg.data.at(5) = (3 * a[5][1] * pow(interval, 2) + 2 * a[5][0] * interval) * 200 * 180 / (9 * PI);
        }

        if(count >= 3 * looptimes && (count  - 3 * looptimes) % (12 * looptimes) <= 6 * looptimes){
            temp_int = (count  - 3 * looptimes) % (12 * looptimes);
            interval = 1.0 * temp_int / looptimes;
            vel_msg.data.at(0) = (5 * b[0][3] * pow(interval, 4) + 4 * b[0][2] * pow(interval, 3) + 3 * b[0][1] * pow(interval, 2) + 2 * b[0][0] * interval) * 30 * 180 / PI;
			vel_msg.data.at(1) = (5 * b[1][3] * pow(interval, 4) + 4 * b[1][2] * pow(interval, 3) + 3 * b[1][1] * pow(interval, 2) + 2 * b[1][0] * interval  + 0.0012 * interval) * 205 * 180 / (3 * PI);
			vel_msg.data.at(2) = (5 * b[2][3] * pow(interval, 4) + 4 * b[2][2] * pow(interval, 3) + 3 * b[2][1] * pow(interval, 2) + 2 * b[2][0] * interval) * 50 * 180 / PI;
			vel_msg.data.at(3) = (5 * b[3][3] * pow(interval, 4) + 4 * b[3][2] * pow(interval, 3) + 3 * b[3][1] * pow(interval, 2) + 2 * b[3][0] * interval) * 125 * 180 / (2 * PI);
			vel_msg.data.at(4) = (5 * b[4][3] * pow(interval, 4) + 4 * b[4][2] * pow(interval, 3) + 3 * b[4][1] * pow(interval, 2) + 2 * b[4][0] * interval) * 125 * 180 / (2 * PI);
			vel_msg.data.at(5) = (5 * b[5][3] * pow(interval, 4) + 4 * b[5][2] * pow(interval, 3) + 3 * b[5][1] * pow(interval, 2) + 2 * b[5][0] * interval) * 200 * 180 / (9 * PI);
			//vel_pub.publish(vel_msg);
            flag = 1;
        }

        if(count >= 3 * looptimes && (count  - 3 * looptimes) % (12 * looptimes) >= 6 * looptimes){
            temp_int = (count  - 3 * looptimes) % (12 * looptimes) - 6 * looptimes;
            interval = 6 - 1.0 * temp_int / looptimes;
            vel_msg.data.at(0) = -(5 * b[0][3] * pow(interval, 4) + 4 * b[0][2] * pow(interval, 3) + 3 * b[0][1] * pow(interval, 2) + 2 * b[0][0] * interval) * 30 * 180 / PI;
			vel_msg.data.at(1) = -(5 * b[1][3] * pow(interval, 4) + 4 * b[1][2] * pow(interval, 3) + 3 * b[1][1] * pow(interval, 2) + 2 * b[1][0] * interval  - 0.0012 * interval) * 205 * 180 / (3 * PI);
			vel_msg.data.at(2) = -(5 * b[2][3] * pow(interval, 4) + 4 * b[2][2] * pow(interval, 3) + 3 * b[2][1] * pow(interval, 2) + 2 * b[2][0] * interval) * 50 * 180 / PI;
			vel_msg.data.at(3) = -(5 * b[3][3] * pow(interval, 4) + 4 * b[3][2] * pow(interval, 3) + 3 * b[3][1] * pow(interval, 2) + 2 * b[3][0] * interval) * 125 * 180 / (2 * PI);
			vel_msg.data.at(4) = -(5 * b[4][3] * pow(interval, 4) + 4 * b[4][2] * pow(interval, 3) + 3 * b[4][1] * pow(interval, 2) + 2 * b[4][0] * interval) * 125 * 180 / (2 * PI);
			vel_msg.data.at(5) = -(5 * b[5][3] * pow(interval, 4) + 4 * b[5][2] * pow(interval, 3) + 3 * b[5][1] * pow(interval, 2) + 2 * b[5][0] * interval) * 200 * 180 / (9 * PI);
			//vel_pub.publish(vel_msg);
            if(flag == 1){
                ring_time ++;
                flag = 0;
            }
        }






         vel_pub.publish(vel_msg);
        count ++;
        if(ring_time >= 9) {
            for(int i = 0; i < 1000;i ++){
                vel_msg.data.at(0) = 0;
                vel_msg.data.at(1) = 0;
                vel_msg.data.at(2) = 0;
                vel_msg.data.at(3) = 0;
                vel_msg.data.at(4) = 0;
                vel_msg.data.at(5) = 0;
                vel_pub.publish(vel_msg);
            }
            break;
        }
        /*joint(1) = joint(1) + joint_vel(1) / looptimes;
        joint(2) = joint(2) + joint_vel(2) / looptimes;
        joint(3) = joint(3) + joint_vel(3) / looptimes;
        joint(4) = joint(4) + joint_vel(4) / looptimes;
        joint(5) = joint(5) + joint_vel(5) / looptimes;*/
        /*if(count <= 12 * looptimes)
        ROS_INFO("velocity:%f,%f,%f,%f,%f,%f\ncount:%d\n ",vel(0), vel(1), vel(2), vel(3), vel(4), vel(5), count);*/

        loop_rate.sleep();
    }

    return 0;

}

