#include <string>
#include <ros/ros.h>
#include <iostream>
#include <time.h>
#include <unistd.h>
#include <math.h>
#include "vector"
#include "std_msgs/Float32.h"
#include "std_msgs/Float32MultiArray.h"
#include "controller_manager_msgs/SwitchController.h"
#include "controller_manager_msgs/ListControllers.h"
#include "ikfast.h"
#include "probot_anno_manipulator_ikfast_moveit_plugin.cpp"

using namespace ikfast_kinematics_plugin;
using namespace std;

int main(int argc, char **argv)
{

    double a[6][4];
    double t;
    bool ret;
    int i, j;
    ros::init(argc, argv, "trajectory");
    ros::NodeHandle node_handle;
    ros::AsyncSpinner spinner(1);
    ros::Publisher vel_pub = node_handle.advertise<std_msgs::Float32MultiArray>("speed_chatter", 1000);
    ikfast_kinematics_plugin::IKFastKinematicsPlugin ik;
    ret = ik.IKFastKinematicsPlugin::initialize("robot_description", "manipulator", "base_link", "link_6", 0.001);
    geometry_msgs::Pose target_pose;
    std_msgs::Float32MultiArray init_vel;

    std::vector<geometry_msgs::Pose> pose1, pose2, pose3;
    std::vector<std::vector<double>> sol_rad1, sol_rad2, sol_rad3;
    kinematics::KinematicsResult kinematic_result1, kinematic_result2, kinematic_result3;
    std::vector<double> seed;

    seed.push_back(0.0);
    seed.push_back(0.0);
    seed.push_back(0.0);
    seed.push_back(0.0);
    seed.push_back(0.0);
    seed.push_back(0.0);

    //第一个点：
    target_pose.position.x = 0.3;
    target_pose.position.y = 0.25;
    target_pose.position.z = 0.322 - 0.022;
    target_pose.orientation.w = 0.5;
    target_pose.orientation.x = 0.5;
    target_pose.orientation.y = 0.5;
    target_pose.orientation.z = 0.5;

    pose1.push_back(target_pose);

    ret = ik.getPositionIK(pose1, seed, sol_rad1, kinematic_result1, kinematics::KinematicsQueryOptions());

    cout << "sol_rad1: ";
    if (ret)
    {
        std::cout << sol_rad1.size() << " IK solved successfully." << endl;

        for (int q = 0; q < sol_rad1.size(); q++)
        {
            sol_rad1[q][5] += 1.5708;
            for (int i = 0; i < 6; i++)
            {
                cout << sol_rad1[q][i] << "  ";
            }
            cout << endl;
        }
    }

    //第二个点：
    target_pose.position.x = 0.3;
    target_pose.position.y = 0.1;
    target_pose.position.z = 0.172 - 0.022;
    target_pose.orientation.w = 0.5;
    target_pose.orientation.x = 0.5;
    target_pose.orientation.y = 0.5;
    target_pose.orientation.z = 0.5;

    pose2.push_back(target_pose);

    ret = ik.getPositionIK(pose2, seed, sol_rad2, kinematic_result2, kinematics::KinematicsQueryOptions());

    cout << "sol_rad2: ";
    if (ret)
    {
        std::cout << sol_rad2.size() << " IK solved successfully." << endl;

        for (int q = 0; q < sol_rad2.size(); q++)
        {
            sol_rad2[q][5] += 1.5708;
            for (int i = 0; i < 6; i++)
            {
                cout << sol_rad2[q][i] << "  ";
            }
            cout << endl;
        }
    }

    //第三个点：
    target_pose.position.x = 0.3;
    target_pose.position.y = -0.1;
    target_pose.position.z = 0.122 - 0.022;
    target_pose.orientation.w = 0.5;
    target_pose.orientation.x = 0.5;
    target_pose.orientation.y = 0.5;
    target_pose.orientation.z = 0.5;

    pose3.push_back(target_pose);

    ret = ik.getPositionIK(pose3, seed, sol_rad3, kinematic_result3, kinematics::KinematicsQueryOptions());

    cout << "sol_rad3: ";
    if (ret)
    {
        std::cout << sol_rad3.size() << " IK solved successfully." << endl;

        for (int q = 0; q < sol_rad3.size(); q++)
        {
            sol_rad3[q][5] += 1.5708;
            for (int i = 0; i < 6; i++)
            {
                cout << sol_rad3[q][i] << "  ";
            }
            cout << endl;
        }
    }

    for (i = 0; i < 6; i++)
    {
        a[i][0] = 0.70875 * sol_rad1[1][i] - 1.03316 * sol_rad2[1][i] + 0.52662 * sol_rad3[1][i];
        a[i][1] = -0.25875 * sol_rad1[1][i] + 0.43622 * sol_rad2[1][i] - 0.23307 * sol_rad3[1][i];
        a[i][2] = 0.03125 * sol_rad1[1][i] - 0.05867 * sol_rad2[1][i] + 0.03305 * sol_rad3[1][i];
        a[i][3] = -0.00125 * sol_rad1[1][i] + 0.00255 * sol_rad2[1][i] - 0.0015 * sol_rad3[1][i];
    }

    init_vel.data.push_back(0);
    init_vel.data.push_back(0);
    init_vel.data.push_back(0);
    init_vel.data.push_back(0);
    init_vel.data.push_back(0);
    init_vel.data.push_back(0);
    sleep(1);

    ROS_INFO_STREAM("start");
    for (i = 0; i < 90000; i++)
    {
        t = i / 10000.0;
        init_vel.data.at(0) = 5 * a[0][3] * pow(t, 4) + 4 * a[0][2] * pow(t, 3) + 3 * a[0][1] * pow(t, 2) + 2 * a[0][0] * t;
        init_vel.data.at(1) = 5 * a[1][3] * pow(t, 4) + 4 * a[1][2] * pow(t, 3) + 3 * a[1][1] * pow(t, 2) + 2 * a[1][0] * t;
        init_vel.data.at(2) = 5 * a[2][3] * pow(t, 4) + 4 * a[2][2] * pow(t, 3) + 3 * a[2][1] * pow(t, 2) + 2 * a[2][0] * t;
        init_vel.data.at(3) = 5 * a[3][3] * pow(t, 4) + 4 * a[3][2] * pow(t, 3) + 3 * a[3][1] * pow(t, 2) + 2 * a[3][0] * t;
        init_vel.data.at(4) = 5 * a[4][3] * pow(t, 4) + 4 * a[4][2] * pow(t, 3) + 3 * a[4][1] * pow(t, 2) + 2 * a[4][0] * t;
        init_vel.data.at(5) = 5 * a[5][3] * pow(t, 4) + 4 * a[5][2] * pow(t, 3) + 3 * a[5][1] * pow(t, 2) + 2 * a[5][0] * t;
        init_vel.data.at(0) = init_vel.data.at(0) * 30 * 180 / 3.1415926;
        init_vel.data.at(1) = init_vel.data.at(1) * 205 * 180 / 3.1415926 / 3;
        init_vel.data.at(2) = init_vel.data.at(2) * 50 * 180 / 3.1415926;
        init_vel.data.at(3) = init_vel.data.at(3) * 125 * 180 / 3.1415926 / 2;
        init_vel.data.at(4) = init_vel.data.at(4) * 125 * 180 / 3.1415926 / 2;
        init_vel.data.at(5) = init_vel.data.at(5) * 200 * 180 / 3.1415926 / 9;
        vel_pub.publish(init_vel);
        usleep(17);
    }

    ROS_INFO_STREAM("end");
    init_vel.data.at(0) = 0.0;
    init_vel.data.at(1) = 0.0;
    init_vel.data.at(2) = 0.0;
    init_vel.data.at(3) = 0.0;
    init_vel.data.at(4) = 0.0;
    init_vel.data.at(5) = 0.0;
    for (i = 0; i < 10000; i++)
    {
        vel_pub.publish(init_vel);
    }
}