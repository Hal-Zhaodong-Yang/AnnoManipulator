#include<ros/ros.h>
#include "std_msgs/Float32MultiArray.h"
#include "controller_manager_msgs/SwitchController.h"
#include "controller_manager_msgs/ListControllers.h"
#include <iostream>
#include <cmath>
#include <Eigen/Dense>

using namespace std;
using namespace Eigen;

Matrix<double, 6, 6> jacobm(Matrix<double, 6, 1> theta);

Matrix<double, 6, 6> jacobm(Matrix<double, 6, 1> theta)
{
    Matrix4d t10, t21, t32, t43, t54, t65; //
    Matrix3d r10, r21, r32, r43, r54, r65;//

    t10 << cos(theta(0)), -sin(theta(0)), 0, 0,
    sin(theta(0)), cos(theta(0)), 0, 0,
    0, 0, 1, 0,
    0, 0, 0, 1;
    r10 << cos(theta(0)), -sin(theta(0)), 0,
    sin(theta(0)), cos(theta(0)), 0,
    0, 0, 1;
    t21 <<  -sin(theta(1)), -cos(theta(1)), 0, 0,
    0, 0, -1, 0,
    cos(theta(1)), -sin(theta(1)), 0, 0,
    0, 0, 0, 1;
    r21 << -sin(theta(1)), -cos(theta(1)), 0,
    0, 0, -1,
    cos(theta(1)), -sin(theta(1)), 0;
    t32 << cos(theta(2)), -sin(theta(2)), 0, 0.225,
    sin(theta(2)), cos(theta(2)), 0, 0,
    0, 0, 1, 0,
    0, 0, 0, 1;
    r32 << cos(theta(2)), -sin(theta(2)), 0,
    sin(theta(2)), cos(theta(2)), 0,
    0, 0, 1;
    t43 << cos(theta(3)), -sin(theta(3)), 0, 0,
    0, 0, -1, -0.2289,
    sin(theta(3)), cos(theta(3)), 0, 0,
    0, 0, 0, 1;
    r43 << cos(theta(3)), -sin(theta(3)), 0,
    0, 0, -1,
    sin(theta(3)), cos(theta(3)), 0;
    t54 << sin(theta(4)), cos(theta(4)), 0, 0,
    0, 0, 1, 0,
    cos(theta(4)), -sin(theta(4)), 0, 0,
    0, 0, 0, 1;
    r54 << sin(theta(4)), cos(theta(4)), 0,
    0, 0, 1,
    cos(theta(4)), -sin(theta(4)), 0;
    t65 << cos(theta(5)), -sin(theta(5)), 0, 0,
    0, 0, -1, 0,
    sin(theta(5)), cos(theta(5)),0, 0,
    0, 0, 0, 1;
    r65 << cos(theta(5)), -sin(theta(5)), 0,
    0, 0, -1,
    sin(theta(5)), cos(theta(5)),0;
    Matrix4d t76;
    Matrix3d r76;
    t76 << 1, 0, 0, 0,
    0, 0, 1, 0,
    0, -1, 0, 0.055,
    0, 0, 0, 1;
    r76 << 1, 0, 0,
    0, 0, 1,
    0, -1, 0;

    Vector3d z1, z2, z3, z4, z5, z6, z7;
    Vector3d p1, p2, p3, p4, p5, p6, p7;
    Vector3d z;
    Matrix<double, 4, 1>  ptemp,p;
    z << 0, 0, 1;
    p << 0, 0, 0,1;
    z1 = r10 * z;
    z2 = r10 * r21 * z;
    z3 = r10 * r21 * r32 * z;
    z4 = r10 * r21 * r32 * r43 * z;
    z5 = r10 * r21 * r32 * r43 * r54 * z;
    z6 = r10 * r21 * r32 * r43 * r54 * r65 * z;
    z7 = r10 * r21 * r32 * r43 * r54 * r65 * r76 * z;

    ptemp = t10 * p;
    p1 = ptemp.block(0, 0, 3, 1);
    ptemp = t10 * t21 * p;
    p2 = ptemp.block(0, 0, 3, 1);
    ptemp = t10 * t21 * t32 * p;
    p3 = ptemp.block(0, 0, 3, 1);
    ptemp = t10 * t21 * t32 * t43 * p;
    p4 = ptemp.block(0, 0, 3, 1);
    ptemp = t10 * t21 * t32 * t43 * t54 * p;
    p5 = ptemp.block(0, 0, 3, 1);
    ptemp = t10 * t21 * t32 * t43 * t54 * t65 * p;
    p6 = ptemp.block(0, 0, 3, 1);
    ptemp = t10 * t21 * t32 * t43 * t54 * t65 * t76 * p;
    p7 = ptemp.block(0, 0, 3, 1);
    
    

    Matrix<double, 6, 7>  jacob;
    jacob.block(0, 0, 3, 1) = z1.cross(p7 - p1);
    jacob.block(3, 0, 3, 1) = z1;
    jacob.block(0, 1, 3, 1) = z2.cross(p7 - p2);
    jacob.block(3, 1, 3, 1) = z2;
    jacob.block(0, 2, 3, 1) = z3.cross(p7 - p3);
    jacob.block(3, 2, 3, 1) = z3;
    jacob.block(0, 3, 3, 1) = z4.cross(p7 - p4);
    jacob.block(3, 3, 3, 1) = z4;
    jacob.block(0, 4, 3, 1) = z5.cross(p7 - p5);
    jacob.block(3, 4, 3, 1) = z5;
    jacob.block(0, 5, 3, 1) = z6.cross(p7 - p6);
    jacob.block(3, 5, 3, 1) = z6;
    jacob.block(0, 6, 3, 1)  << 0, 0, 0;
    jacob.block(3, 6, 3, 1) = z7;

    /*Matrix<double, 6, 7> jacob;

    jacob << 0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0;*/

    Matrix<double, 6, 6> jacob66;
    jacob66 = jacob.block(0, 0, 6, 6);

    return jacob66;

}

int main(int argc, char **argv)
{
    ros::init(argc, argv, "jacob");

    ros::NodeHandle vel_control;

    ros::Publisher vel_pub = vel_control.advertise<std_msgs::Float32MultiArray>("speed_chatter", 1000);

    int looptimes = 10;
    ros::Rate loop_rate(looptimes);

    int count = 0;

    Matrix<double, 6, 6> jacobtemp;
    Matrix<double, 6, 1> joint, joint_vel;
    Matrix<double, 6, 1> vel;
    vel << 0, 0, 0, 0, 0, 0;
    joint << 0, 0, 0, 0, 0, 0;
    joint_vel << 0, 0, 0, 0, 0, 0;
    Matrix<double, 6, 1> a1, a2, a3, a4, a5;
    a1 << 0, 0, 0, 0.01, 0, 0.01;
    a2 << 0, 0, 0, -0.01, -0.01, -0.02;
    a3 << 0, 0, 0, -0.01, 0.01, 0;
    a4 << 0, 0, 0, 0.01, 0.01, 0.02;
    a5 << 0, 0, 0, 0, -0.01, -0.01;
    int inter = 5;

    while(ros::ok())
    {
        jacobtemp = jacobm(joint);
        std_msgs::Float32MultiArray vel_msg;
        vel_msg.data.push_back(0);
        vel_msg.data.push_back(0);
        vel_msg.data.push_back(0);
        vel_msg.data.push_back(0);
        vel_msg.data.push_back(0);
        vel_msg.data.push_back(0);
        joint_vel = jacobtemp.inverse() * vel;
        vel_msg.data.at(0) = joint_vel(0) * 30 * 180 / 3.1415926535897;
        vel_msg.data.at(1) = joint_vel(1) * 205 * 180 / 3.1415926535897 / 3;
        vel_msg.data.at(2) = joint_vel(2) * 50 * 180 / 3.1415926535897;
        vel_msg.data.at(3) = joint_vel(3) * 125 * 180 / 3.1415926535897 / 2;
        vel_msg.data.at(4) = joint_vel(4) * 125 * 180 / 3.1415926535897 / 2;
        vel_msg.data.at(5) = joint_vel(5) * 200 * 180 / 3.1415926535897 / 9;

        vel_pub.publish(vel_msg);

        count ++;
        if(count <= inter * looptimes){
            vel = vel +  a1 / looptimes;
        }
        if(count >= 2 * inter * looptimes && count <= 3 * inter * looptimes){
            vel = vel + a2 / looptimes;
        }
        if(count >= 4 * inter * looptimes && count <= 5 * inter * looptimes){
            vel = vel + a3 / looptimes;
        }
        if(count >= 6 * inter * looptimes && count <= 7 * inter * looptimes){
            vel = vel + a4 / looptimes;
        }
        if(count >= 8 * inter * looptimes && count <= 9 * inter * looptimes){
            vel = vel + a5 / looptimes;
        }
        joint = joint + joint_vel / looptimes;
        /*joint(1) = joint(1) + joint_vel(1) / looptimes;
        joint(2) = joint(2) + joint_vel(2) / looptimes;
        joint(3) = joint(3) + joint_vel(3) / looptimes;
        joint(4) = joint(4) + joint_vel(4) / looptimes;
        joint(5) = joint(5) + joint_vel(5) / looptimes;*/
        /*if(count <= 12 * looptimes)
        ROS_INFO("velocity:%f,%f,%f,%f,%f,%f\ncount:%d\n ",vel(0), vel(1), vel(2), vel(3), vel(4), vel(5), count);*/

        loop_rate.sleep();
    }

    
    /*Matrix<double, 6, 1> theta1;
    theta1 << 0, 0, 0, 0, 0, 0;
    cout << "jacob" << endl << jacobm(theta1) << endl;*/

    return 0;

}