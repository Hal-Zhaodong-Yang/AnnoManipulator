#include<ros/ros.h>
#include "controller_manager_msgs/SwitchController.h"
#include "controller_manager_msgs/ListControllers.h"
#include <iostream>
#include<cmath>
#include <Eigen/Dense>

#include <time.h>
#include "vector"
#include "std_msgs/Float32MultiArray.h"
#include "controller_manager_msgs/SwitchController.h"
#include "controller_manager_msgs/ListControllers.h"
#include "ikfast.h"
#include "probot_anno_manipulator_ikfast_moveit_plugin.cpp"


using namespace Eigen;
using namespace std;

Matrix4d kinetic(Matrix<double, 6, 1> theta);
Matrix<double, 6, 1> revkinetic(Matrix<double, 6, 1> pos);
Matrix<double, 6, 1> pos_pos(Matrix4d t);
Matrix<double, 6, 1> pieper_thetar(Matrix<double, 6, 1> theta, Matrix4d t60);
Matrix<double, 6, 1> pieper_theta0(Matrix<double, 6, 1> theta, Matrix4d t60);
Matrix<double, 6, 1> pieper_theta1(Matrix<double, 6, 1> theta, Matrix4d t60, double t);
Matrix<double, 6, 1> pieper_t1(Matrix<double, 6, 1> theta, Matrix4d t60);
Matrix<double, 6, 1> pieper_theta2(Matrix4d t60);

Matrix<double, 6, 1> pieper_thetar(Matrix<double, 6, 1> theta, Matrix4d t60)
{
    Matrix3d r10, r21, r32,r60;
    r10 << cos(theta(0)), -sin(theta(0)), 0,
    sin(theta(0)), cos(theta(0)), 0,
    0, 0, 1;
    r21 <<  -sin(theta(1)), -cos(theta(1)), 0,
    0, 0, -1,
    cos(theta(1)), -sin(theta(1)), 0;
    r32 << cos(theta(2)), -sin(theta(2)), 0,
    sin(theta(2)), cos(theta(2)), 0,
    0, 0, 1;
    for(int i = 0;i <= 2;i ++){
        for(int j = 0;j <= 2;j ++){
            r60(i, j) = t60(i,j);
        }
    }
    Matrix3d r43_0, r40_0, r64_0;
    r43_0 << 1, 0, 0,
    0, 0, -1,
    0, 1, 0;
    r40_0 = r10 * r21 * r32 * r43_0;
    r64_0 = r40_0.inverse() * r60;
   /* theta(4) = atan2(-r64_0(2, 0), sqrt(r64_0(0, 0) * r64_0(0, 0) + r64_0(1, 0) * r64_0(1, 0)));
    theta(3) = atan2(r64_0(1, 0) / cos(theta(4)), r64_0(0, 0) / cos(theta(4)));
    theta(5) = atan2(r64_0(2, 1) / cos(theta(4)), r64_0(2, 2) / cos(theta(4)));*/
    Matrix3d r46_000,r66_0;
    r46_000 << 0, 0, 1,
    0, 1, 0,
    -1, 0, 0;
    r66_0 = r46_000 * r64_0;
    theta(4) = atan2(r66_0(0, 2), sqrt(r66_0(1, 2) * r66_0(1, 2) + r66_0(2, 2) * r66_0(2, 2)));
    if(theta(4) <= 0){
        theta(4) = -theta(4);
    }
    theta(3) = atan2(-r66_0(1, 2) / cos(theta(4)), r66_0(2, 2) / cos(theta(4)));
    theta(5) = atan2(-r66_0(0, 1) / cos(theta(4)), r66_0(0, 0) / cos(theta(4)));

    MatrixXd nosol(6, 1);
    nosol << 200, 0, 0, 0, 0, 0;

    Matrix4d t76,t70;
    t76 << 1, 0, 0, 0,
    0, 0, 1, 0,
    0, -1, 0, 0.055,
    0, 0, 0, 1;
    t70 = t60 * t76;

    Matrix<double, 6, 1> position, position_sol;

    position = pos_pos(t70);

    MatrixXd ev(6, 1);
    double e;


    if(isnan(theta(0)) || isnan(theta(1)) || isnan(theta(2)) || isnan(theta(3)) || isnan(theta(4)) || isnan(theta(5))){
        return nosol;
    }else{
        position_sol = pos_pos(kinetic(theta));
        ev = position - position_sol;
        e = sqrt(ev(0) * ev(0) + ev(1) * ev(1) + ev(2) * ev(2) + ev(3) * ev(3) + ev(4) * ev(4) + ev(5) * ev(5));
        if(e >= 0.01){
            return nosol;
        }else return theta;

    }



}



Matrix<double, 6, 1> pieper_theta0(Matrix<double, 6, 1> theta, Matrix4d t60)
{
    double f1, f2;
    f1 = 0.2289 * sin(theta(2)) + 0.225;
    f2 = -0.2289 * cos(theta(2)); 
    Matrix<double, 6, 1> theta1;
    theta1 = theta;
    theta(0) = acos(t60(0,3) / (-sin(theta(1)) * f1 - cos(theta(1)) * f2));
    theta(0) = floor(theta(0) * 1000000000.0 + 0.5) / 1000000000.0;
    theta1(0) = -theta(0);

    Matrix<double, 6, 1> sol1, sol2;
    sol1 = pieper_thetar(theta, t60);
    sol2 = pieper_thetar(theta1, t60);
    MatrixXd nosol(6, 1);
    nosol << 200, 0, 0, 0, 0, 0;
    if(sol1(0) <= 100) return sol1;
    else if(sol2(0) <= 100) return sol2;
    else return nosol;

}



Matrix<double, 6, 1> pieper_theta1(Matrix<double, 6, 1> theta, Matrix4d t60, double t)
{
    Matrix<double, 6, 1> theta1;
    theta1 = theta;
    theta(1) = atan(t);
    if(theta(1) >= 1.1316){
        theta1(1) = theta(1) - 3.14159265;
    }else if(theta(1) <= -1.1316){
        theta1(1) = theta(1) + 3.14159265;
    }else {
        theta1(1) = theta(1);
    }
    theta(1) = floor(theta(1) * 1000000000.0 + 0.5) / 1000000000.0;
    theta1(1) = floor(theta1(1) * 1000000000.0 + 0.5) / 1000000000.0;

    Matrix<double, 6, 1> sol1, sol2;
    sol1 = pieper_theta0(theta, t60);
    sol2 = pieper_theta0(theta1, t60);
    MatrixXd nosol(6, 1);
    nosol << 200, 0, 0, 0, 0, 0;
    if(sol1(0) <= 100) return sol1;
    else if(sol2(0) <= 100) return sol2;
    else return nosol;

}


Matrix<double, 6, 1> pieper_t1(Matrix<double, 6, 1> theta, Matrix4d t60)
{
    double f1, f2;
    f1 = 0.2289 * sin(theta(2)) + 0.225;
    f2 = -0.2289 * cos(theta(2)); 
    double t1,t2;
    t1 = (2 * f1 * f2 - sqrt(4 * f1 * f1 * f2 *f2 - 4 * (f2 * f2 - t60(2, 3) * t60(2, 3)) * (f1 * f1 - t60(2, 3) * t60(2, 3)))) / (2 * (f2 * f2 - t60(2, 3) * t60(2, 3)));
    t2 = (2 * f1 * f2 + sqrt(4 * f1 * f1 * f2 *f2 - 4 * (f2 * f2 - t60(2, 3) * t60(2, 3)) * (f1 * f1 - t60(2, 3) * t60(2, 3)))) / (2 * (f2 * f2 - t60(2, 3) * t60(2, 3)));
    
    Matrix<double, 6, 1> sol1, sol2;
    sol1 = pieper_theta1(theta, t60, t1);
    sol2 = pieper_theta1(theta, t60, t2);
    MatrixXd nosol(6, 1);
    nosol << 200, 0, 0, 0, 0, 0;
    if(sol1(0) <= 100) return sol1;
    else if(sol2(0) <= 100) return sol2;
    else return nosol;

}

Matrix<double, 6, 1> pieper_theta2(Matrix4d t60)
{
    Matrix<double, 6, 1> theta, theta1;
    Matrix<double, 6, 1> sol1, sol2;
    theta << 0, 0, 0, 0, 0, 0;
    theta1 << 0, 0, 0, 0, 0, 0;
    double r = t60(0, 3) * t60(0, 3) + t60(1, 3) * t60(1, 3) + t60(2, 3) *t60(2, 3);
    theta(2) = asin((r - 0.2289 * 0.2289 - 0.225 * 0.225)/(2 * 0.2289 * 0.225));
    if(theta(2) >= 0){
        theta1(2) = 3.14159265 - theta(2);
    }else{
        theta1(2) = theta(2);
    }

    theta(2) = floor(theta(2) * 1000000000.0 + 0.5) / 1000000000.0;
    theta1(2) = floor(theta1(2) * 1000000000.0 + 0.5) / 1000000000.0;

    sol1 = pieper_t1(theta, t60);
    sol2 = pieper_t1(theta1, t60);
    MatrixXd nosol(6, 1);
    nosol << 200, 0, 0, 0, 0, 0;
    if(sol1(0) <= 100) return sol1;
    else if(sol2(0) <= 100) return sol2;
    else return nosol;


}


Matrix4d kinetic(Matrix<double, 6, 1> theta)
{
    Matrix4d t10, t21, t32, t43, t54, t65; //
    t10 << cos(theta(0)), -sin(theta(0)), 0, 0,
    sin(theta(0)), cos(theta(0)), 0, 0,
    0, 0, 1, 0,
    0, 0, 0, 1;
    t21 <<  -sin(theta(1)), -cos(theta(1)), 0, 0,
    0, 0, -1, 0,
    cos(theta(1)), -sin(theta(1)), 0, 0,
    0, 0, 0, 1;
    t32 << cos(theta(2)), -sin(theta(2)), 0, 0.225,
    sin(theta(2)), cos(theta(2)), 0, 0,
    0, 0, 1, 0,
    0, 0, 0, 1;
    t43 << cos(theta(3)), -sin(theta(3)), 0, 0,
    0, 0, -1, -0.2289,
    sin(theta(3)), cos(theta(3)), 0, 0,
    0, 0, 0, 1;
    t54 << sin(theta(4)), cos(theta(4)), 0, 0,
    0, 0, 1, 0,
    cos(theta(4)), -sin(theta(4)), 0, 0,
    0, 0, 0, 1;
    t65 << cos(theta(5)), -sin(theta(5)), 0, 0,
    0, 0, -1, 0,
    sin(theta(5)), cos(theta(5)),0, 0,
    0, 0, 0, 1;
    Matrix4d t76;
    t76 << 1, 0, 0, 0,
    0, 0, 1, 0,
    0, -1, 0, 0.055,
    0, 0, 0, 1;
    //test
    /*Matrix4d t60;
    t60 =   t10 * t21 * t32 * t43 * t54 * t65;
    cout << "kinetic t60" << endl << t60 << endl;*/
    Matrix4d t70 = t10 * t21 * t32 * t43 * t54 * t65 * t76;

    return t70;

}
/*
Matrix<double, 6, 1> revkinetic(Matrix<double, 6, 1> pos)
{
    Matrix4d t70;
    t70(0,3) = pos(0);
    t70(1,3) = pos(1);
    t70(2,3) = pos(2);
    t70(3,3) = 1;
    t70(3,0) = 0;
    t70(3,1) = 0;
    t70(3,2) = 0;
    Matrix3d rotx, roty, rotz;
    rotx << 1, 0, 0,
    0, cos(pos(3)), -sin(pos(3)),
    0, sin(pos(3)), cos(pos(3));
    roty << cos(pos(4)), 0, sin(pos(4)),
    0, 1, 0,
    -sin(pos(4)), 0, cos(pos(4));
    rotz << cos(pos(5)), -sin(pos(5)), 0,
    sin(pos(5)), cos(pos(5)), 0,
    0, 0, 1;
    Matrix3d rot = rotz * roty * rotx;
    for(int i = 0;i <= 2;i ++){
        for(int j = 0;j <= 2;j ++){
            t70(i,j) = rot(i,j);
        }
    }

    Matrix4d t67;
    t67 << 1, 0, 0, 0,
    0, 0, -1, 0.055,
    0, 1, 0, 0,
    0, 0, 0, 1;
    Matrix4d t60 = t70 * t67;

    //cout <<"t60 "<<endl  << t60 << endl << endl;

    //pieper

    return pieper_theta2(t60);

}*/

Matrix<double, 6, 1> pos_pos(Matrix4d t)
{
    MatrixXd pos(6,1);
    pos(0) = t(0,3);
    pos(1) = t(1,3);
    pos(2) = t(2,3);
    pos(4) = atan2(-t(2,0),sqrt(t(0,0) * t(0,0) + t(1,0) * t(1, 0)));
    pos(5) = atan2(t(1,0)/cos(pos(4)),t(0,0)/cos(pos(4)));
    pos(3) = atan2(t(2,1)/cos(pos(4)), t(2,2)/cos(pos(4)));

    return pos;
}

Matrix<double, 6, 1> revkinetic(Matrix<double, 6, 1> pos)
{
    Matrix4d t70;
    t70(0,3) = pos(0);
    t70(1,3) = pos(1);
    t70(2,3) = pos(2);
    t70(3,3) = 1;
    t70(3,0) = 0;
    t70(3,1) = 0;
    t70(3,2) = 0;
    Matrix3d rotx, roty, rotz;
    rotx << 1, 0, 0,
    0, cos(pos(3)), -sin(pos(3)),
    0, sin(pos(3)), cos(pos(3));
    roty << cos(pos(4)), 0, sin(pos(4)),
    0, 1, 0,
    -sin(pos(4)), 0, cos(pos(4));
    rotz << cos(pos(5)), -sin(pos(5)), 0,
    sin(pos(5)), cos(pos(5)), 0,
    0, 0, 1;
    Matrix3d rot = rotz * roty * rotx;
    for(int i = 0;i <= 2;i ++){
        for(int j = 0;j <= 2;j ++){
            t70(i,j) = rot(i,j);
        }
    }

    Matrix4d t67;
    t67 << 1, 0, 0, 0,
    0, 0, -1, 0.055,
    0, 1, 0, 0,
    0, 0, 0, 1;
    Matrix4d t60 = t70 * t67;

    cout <<"t60 "<<endl  << t60 << endl << endl;

    //pieper

    MatrixXd theta(6, 1);
    double r = t60(0, 3) * t60(0, 3) + t60(1, 3) * t60(1, 3) + t60(2, 3) *t60(2, 3);
    theta(2) = asin((r - 0.2289 * 0.2289 - 0.225 * 0.225)/(2 * 0.2289 * 0.225));
    theta(2) = floor(theta(2) * 1000000000.0 + 0.5) / 1000000000.0;
    double f1, f2;
    f1 = 0.2289 * sin(theta(2)) + 0.225;
    f2 = -0.2289 * cos(theta(2)); 
    //theta(1) = asin(-t60(2,3)/sqrt(f1 * f1 + f2 * f2)) + atan(f1/f2);
    double t1,t2;
    t1 = (2 * f1 * f2 - sqrt(4 * f1 * f1 * f2 *f2 - 4 * (f2 * f2 - t60(2, 3) * t60(2, 3)) * (f1 * f1 - t60(2, 3) * t60(2, 3)))) / (2 * (f2 * f2 - t60(2, 3) * t60(2, 3)));
    t2 = (2 * f1 * f2 + sqrt(4 * f1 * f1 * f2 *f2 - 4 * (f2 * f2 - t60(2, 3) * t60(2, 3)) * (f1 * f1 - t60(2, 3) * t60(2, 3)))) / (2 * (f2 * f2 - t60(2, 3) * t60(2, 3)));
    double sol1, sol2;
    sol1 = atan(t1);
    sol2 = atan(t2);
    theta(1) = sol1;
    theta(1) = floor(theta(1) * 1000000000.0 + 0.5) / 1000000000.0;
    theta(0) = acos(t60(0,3) / (-sin(theta(1)) * f1 - cos(theta(1)) * f2));
    theta(0) = floor(theta(0) * 1000000000.0 + 0.5) / 1000000000.0;

    Matrix3d r10, r21, r32,r60;
    r10 << cos(theta(0)), -sin(theta(0)), 0,
    sin(theta(0)), cos(theta(0)), 0,
    0, 0, 1;
    r21 <<  -sin(theta(1)), -cos(theta(1)), 0,
    0, 0, -1,
    cos(theta(1)), -sin(theta(1)), 0;
    r32 << cos(theta(2)), -sin(theta(2)), 0,
    sin(theta(2)), cos(theta(2)), 0,
    0, 0, 1;
    for(int i = 0;i <= 2;i ++){
        for(int j = 0;j <= 2;j ++){
            r60(i, j) = t60(i,j);
        }
    }
    Matrix3d r43_0, r40_0, r64_0;
    r43_0 << 1, 0, 0,
    0, 0, -1,
    0, 1, 0;
    r40_0 = r10 * r21 * r32 * r43_0;
    r64_0 = r40_0.inverse() * r60;
   /* theta(4) = atan2(-r64_0(2, 0), sqrt(r64_0(0, 0) * r64_0(0, 0) + r64_0(1, 0) * r64_0(1, 0)));
    theta(3) = atan2(r64_0(1, 0) / cos(theta(4)), r64_0(0, 0) / cos(theta(4)));
    theta(5) = atan2(r64_0(2, 1) / cos(theta(4)), r64_0(2, 2) / cos(theta(4)));*/
    Matrix3d r46_000,r66_0;
    r46_000 << 0, 0, 1,
    0, 1, 0,
    -1, 0, 0;
    r66_0 = r46_000 * r64_0;
    theta(4) = atan2(r66_0(0, 2), sqrt(r66_0(1, 2) * r66_0(1, 2) + r66_0(2, 2) * r66_0(2, 2)));
    theta(3) = atan2(-r66_0(1, 2) / cos(theta(4)), r66_0(2, 2) / cos(theta(4)));
    theta(5) = atan2(-r66_0(0, 1) / cos(theta(4)), r66_0(0, 0) / cos(theta(4)));
    /*theta(4) = atan2(-r66_0(2, 0), sqrt(r66_0(0, 0) * r66_0(0, 0) + r66_0(1, 0) * r66_0(1, 0)));
    theta(3) = atan2(r66_0(1, 0) / cos(theta(4)), r66_0(0, 0) / cos(theta(4)));
    theta(5) = atan2(r66_0(2, 1) / cos(theta(4)), r66_0(2, 2) / cos(theta(4)));*/

    if(isnan(theta(0)) || isnan(theta(1)) || isnan(theta(2)) || isnan(theta(3)) || isnan(theta(4)) || isnan(theta(5))){
        theta(1) = sol2;
        theta(1) = floor(theta(1) * 1000000000.0 + 0.5) / 1000000000.0;
        theta(0) = acos(t60(0,3) / (-sin(theta(1)) * f1 - cos(theta(1)) * f2));
        theta(0) = floor(theta(0) * 1000000000.0 + 0.5) / 1000000000.0;

        Matrix3d r10, r21, r32,r60;
        r10 << cos(theta(0)), -sin(theta(0)), 0,
        sin(theta(0)), cos(theta(0)), 0,
        0, 0, 1;
        r21 <<  -sin(theta(1)), -cos(theta(1)), 0,
        0, 0, -1,
        cos(theta(1)), -sin(theta(1)), 0;
        r32 << cos(theta(2)), -sin(theta(2)), 0,
        sin(theta(2)), cos(theta(2)), 0,
        0, 0, 1;
        for(int i = 0;i <= 2;i ++){
            for(int j = 0;j <= 2;j ++){
                r60(i, j) = t60(i,j);
            }
        }
        Matrix3d r43_0, r40_0, r64_0;
        r43_0 << 1, 0, 0,
        0, 0, -1,
        0, 1, 0;
        r40_0 = r10 * r21 * r32 * r43_0;
        r64_0 = r40_0.inverse() * r60;
        Matrix3d r46_000,r66_0;
        r46_000 << 0, 0, 1,
        0, 1, 0,
        -1, 0, 0;
        r66_0 = r46_000 * r64_0;
        theta(4) = atan2(r66_0(0, 2), sqrt(r66_0(1, 2) * r66_0(1, 2) + r66_0(2, 2) * r66_0(2, 2)));
        theta(3) = atan2(-r66_0(1, 2) / cos(theta(4)), r66_0(2, 2) / cos(theta(4)));
        theta(5) = atan2(-r66_0(0, 1) / cos(theta(4)), r66_0(0, 0) / cos(theta(4)));
    }

    for(int i = 3;i <= 5;i ++){
         theta(i) = floor(theta(i) * 1000000000.0 + 0.5) / 1000000000.0;
    }

    return theta;
}

int main(int argc, char **argv)
{
    ros::init(argc, argv, "kinetic");
    ros::NodeHandle node_handle;
    //ros::Publisher speed_pub = node_handle.advertise<std_msgs::Float32MultiArray>("speed_chatter",1000);
    ros::Publisher position_pub = node_handle.advertise<std_msgs::Float32MultiArray>("position_chatter",1000);

    std_msgs::Float32MultiArray position_msg;
    position_msg.data.push_back(0.0);
    position_msg.data.push_back(0.0);
    position_msg.data.push_back(0.0);
    position_msg.data.push_back(0.0);
    position_msg.data.push_back(0.0);
    position_msg.data.push_back(0.0);
    position_msg.data.push_back(0.0);


    MatrixXd b(6,1);
    b << -0.322, -0.636, -0.011, 0, 0.647, -0.322;
    //b << 0, 0, 1.57, 0, 0, 0;
    /*Matrix4d c = kinetic(b);
    MatrixXd pos(6,1);
    pos =  pos_pos(c);
    cout << "reverse kinetic" << endl << revkinetic(pos) << endl << endl;
    pos(2) += 0.284;
    std::cout << c << std::endl;
    cout << pos << endl;*/

    MatrixXd ter_pos(6, 1);
    ter_pos <<0.3 ,0, 0.122, 1.57, 0, 0;
    ter_pos(2) -= 0.284;
    MatrixXd cal(6, 1);
    cal = pos_pos(kinetic(revkinetic(ter_pos)));
    cal(2) += 0.284;

    MatrixXd joint_angle(6,1);
    joint_angle = revkinetic(ter_pos);

    
    cout << "pos" << endl << cal << endl;
    cout << "joint angle" << endl << revkinetic(ter_pos) << endl;
    
   //joint_angle << -0.322, -0.636, -0.011, 0, 0.647, -0.322;

   position_msg.data.at(0) = joint_angle(0) * 30 * 180 / 3.1415926;
   position_msg.data.at(1) = joint_angle(1) * 205 * 180 / 3.1415926 / 3;
   position_msg.data.at(2) = joint_angle(2) * 50 * 180 / 3.1415926;
   position_msg.data.at(3) = joint_angle(3) * 125 * 180 / 3.1415926 / 2;
   position_msg.data.at(4) = joint_angle(4) * 125 * 180 / 3.1415926 / 2;
   position_msg.data.at(5) = joint_angle(5) * 200 * 180 / 3.1415926 / 9;
   position_msg.data.at(6) = 1200.0;

   sleep(5);

   position_pub.publish(position_msg);
   ROS_INFO_STREAM("published");


    return 0;

}

