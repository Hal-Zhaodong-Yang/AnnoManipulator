#include<ros/ros.h>
#include "std_msgs/Float64MultiArray.h"
#include "controller_manager_msgs/SwitchController.h"
#include "controller_manager_msgs/ListControllers.h"
#include <iostream>
#include<cmath>
#include <Eigen/Dense>
using namespace Eigen;
using namespace std;

Matrix4d kinetic(Matrix<double, 6, 1> theta);
Matrix<double, 6, 1> revkinetic(Matrix<double, 6, 1> pos);
Matrix<double, 6, 1> pos_pos(Matrix4d t);
Matrix<double, 6, 1> pieper_thetar(Matrix<double, 6, 1> theta, Matrix4d t60);
Matrix<double, 6, 1> pieper_theta0(Matrix<double, 6, 1> theta, Matrix4d t60);
Matrix<double, 6, 1> pieper_theta1(Matrix<double, 6, 1> theta, Matrix4d t60, double t);
Matrix<double, 6, 1> pieper_t1(Matrix<double, 6, 1> theta, Matrix4d t60);
Matrix<double, 6, 1> pieper_theta2(Matrix4d t60);

Matrix<double, 6, 1> pieper_thetar(Matrix<double, 6, 1> theta, Matrix4d t60)
{
    Matrix3d r10, r21, r32,r60;
    r10 << cos(theta(0)), -sin(theta(0)), 0,
    sin(theta(0)), cos(theta(0)), 0,
    0, 0, 1;
    r21 <<  -sin(theta(1)), -cos(theta(1)), 0,
    0, 0, -1,
    cos(theta(1)), -sin(theta(1)), 0;
    r32 << cos(theta(2)), -sin(theta(2)), 0,
    sin(theta(2)), cos(theta(2)), 0,
    0, 0, 1;
    for(int i = 0;i <= 2;i ++){
        for(int j = 0;j <= 2;j ++){
            r60(i, j) = t60(i,j);
        }
    }
    Matrix3d r43_0, r40_0, r64_0;
    r43_0 << 1, 0, 0,
    0, 0, -1,
    0, 1, 0;
    r40_0 = r10 * r21 * r32 * r43_0;
    r64_0 = r40_0.inverse() * r60;

    Matrix3d r46_000,r66_0;
    r46_000 << 0, 0, 1,
    0, 1, 0,
    -1, 0, 0;
    r66_0 = r46_000 * r64_0;
    theta(4) = atan2(r66_0(0, 2), sqrt(r66_0(1, 2) * r66_0(1, 2) + r66_0(2, 2) * r66_0(2, 2)));
    if(theta(4) <= 0){
        theta(4) = -theta(4);
    }
    theta(3) = atan2(-r66_0(1, 2) / cos(theta(4)), r66_0(2, 2) / cos(theta(4)));
    theta(5) = atan2(-r66_0(0, 1) / cos(theta(4)), r66_0(0, 0) / cos(theta(4)));

    MatrixXd nosol(6, 1);
    nosol << 200, 0, 0, 0, 0, 0;

    Matrix4d t76,t70;
    t76 << 1, 0, 0, 0,
    0, 0, 1, 0,
    0, -1, 0, 0.055,
    0, 0, 0, 1;
    t70 = t60 * t76;

    Matrix<double, 6, 1> position, position_sol;

    position = pos_pos(t70);

    MatrixXd ev(6, 1);
    double e;


    if(isnan(theta(0)) || isnan(theta(1)) || isnan(theta(2)) || isnan(theta(3)) || isnan(theta(4)) || isnan(theta(5))){
        return nosol;
    }else{
        position_sol = pos_pos(kinetic(theta));
        ev = position - position_sol;
        e = sqrt(ev(0) * ev(0) + ev(1) * ev(1) + ev(2) * ev(2) + ev(3) * ev(3) + ev(4) * ev(4) + ev(5) * ev(5));
        if(e >= 0.01){
            return nosol;
        }else return theta;

    }



}



Matrix<double, 6, 1> pieper_theta0(Matrix<double, 6, 1> theta, Matrix4d t60)
{
    double f1, f2;
    f1 = 0.2289 * sin(theta(2)) + 0.225;
    f2 = -0.2289 * cos(theta(2)); 
    Matrix<double, 6, 1> theta1;
    theta1 = theta;
    theta(0) = acos(t60(0,3) / (-sin(theta(1)) * f1 - cos(theta(1)) * f2));
    theta(0) = floor(theta(0) * 1000000000.0 + 0.5) / 1000000000.0;
    theta1(0) = -theta(0);

    Matrix<double, 6, 1> sol1, sol2;
    sol1 = pieper_thetar(theta, t60);
    sol2 = pieper_thetar(theta1, t60);
    MatrixXd nosol(6, 1);
    nosol << 200, 0, 0, 0, 0, 0;
    if(sol1(0) <= 100) return sol1;
    else if(sol2(0) <= 100) return sol2;
    else return nosol;

}



Matrix<double, 6, 1> pieper_theta1(Matrix<double, 6, 1> theta, Matrix4d t60, double t)
{
    Matrix<double, 6, 1> theta1;
    theta1 = theta;
    theta(1) = atan(t);
    if(theta(1) >= 1.1316){
        theta1(1) = theta(1) - 3.14159265;
    }else if(theta(1) <= -1.1316){
        theta1(1) = theta(1) + 3.14159265;
    }else {
        theta1(1) = theta(1);
    }
    theta(1) = floor(theta(1) * 1000000000.0 + 0.5) / 1000000000.0;
    theta1(1) = floor(theta1(1) * 1000000000.0 + 0.5) / 1000000000.0;

    Matrix<double, 6, 1> sol1, sol2;
    sol1 = pieper_theta0(theta, t60);
    sol2 = pieper_theta0(theta1, t60);
    MatrixXd nosol(6, 1);
    nosol << 200, 0, 0, 0, 0, 0;
    if(sol1(0) <= 100) return sol1;
    else if(sol2(0) <= 100) return sol2;
    else return nosol;

}


Matrix<double, 6, 1> pieper_t1(Matrix<double, 6, 1> theta, Matrix4d t60)
{
    double f1, f2;
    f1 = 0.2289 * sin(theta(2)) + 0.225;
    f2 = -0.2289 * cos(theta(2)); 
    double t1,t2;
    t1 = (2 * f1 * f2 - sqrt(4 * f1 * f1 * f2 *f2 - 4 * (f2 * f2 - t60(2, 3) * t60(2, 3)) * (f1 * f1 - t60(2, 3) * t60(2, 3)))) / (2 * (f2 * f2 - t60(2, 3) * t60(2, 3)));
    t2 = (2 * f1 * f2 + sqrt(4 * f1 * f1 * f2 *f2 - 4 * (f2 * f2 - t60(2, 3) * t60(2, 3)) * (f1 * f1 - t60(2, 3) * t60(2, 3)))) / (2 * (f2 * f2 - t60(2, 3) * t60(2, 3)));
    
    Matrix<double, 6, 1> sol1, sol2;
    sol1 = pieper_theta1(theta, t60, t1);
    sol2 = pieper_theta1(theta, t60, t2);
    MatrixXd nosol(6, 1);
    nosol << 200, 0, 0, 0, 0, 0;
    if(sol1(0) <= 100) return sol1;
    else if(sol2(0) <= 100) return sol2;
    else return nosol;

}

Matrix<double, 6, 1> pieper_theta2(Matrix4d t60)
{
    Matrix<double, 6, 1> theta, theta1;
    Matrix<double, 6, 1> sol1, sol2;
    theta << 0, 0, 0, 0, 0, 0;
    theta1 << 0, 0, 0, 0, 0, 0;
    double r = t60(0, 3) * t60(0, 3) + t60(1, 3) * t60(1, 3) + t60(2, 3) *t60(2, 3);
    theta(2) = asin((r - 0.2289 * 0.2289 - 0.225 * 0.225)/(2 * 0.2289 * 0.225));
    if(theta(2) >= 0){
        theta1(2) = 3.14159265 - theta(2);
    }else{
        theta1(2) = theta(2);
    }

    theta(2) = floor(theta(2) * 1000000000.0 + 0.5) / 1000000000.0;
    theta1(2) = floor(theta1(2) * 1000000000.0 + 0.5) / 1000000000.0;

    sol1 = pieper_t1(theta, t60);
    sol2 = pieper_t1(theta1, t60);
    MatrixXd nosol(6, 1);
    nosol << 200, 0, 0, 0, 0, 0;
    if(sol1(0) <= 100) return sol1;
    else if(sol2(0) <= 100) return sol2;
    else return nosol;


}

Matrix<double, 6, 1> revkinetic(Matrix<double, 6, 1> pos)
{
    Matrix4d t70;
    t70(0,3) = pos(0);
    t70(1,3) = pos(1);
    t70(2,3) = pos(2);
    t70(3,3) = 1;
    t70(3,0) = 0;
    t70(3,1) = 0;
    t70(3,2) = 0;
    Matrix3d rotx, roty, rotz;
    rotx << 1, 0, 0,
    0, cos(pos(3)), -sin(pos(3)),
    0, sin(pos(3)), cos(pos(3));
    roty << cos(pos(4)), 0, sin(pos(4)),
    0, 1, 0,
    -sin(pos(4)), 0, cos(pos(4));
    rotz << cos(pos(5)), -sin(pos(5)), 0,
    sin(pos(5)), cos(pos(5)), 0,
    0, 0, 1;
    Matrix3d rot = rotz * roty * rotx;
    for(int i = 0;i <= 2;i ++){
        for(int j = 0;j <= 2;j ++){
            t70(i,j) = rot(i,j);
        }
    }

    Matrix4d t67;
    t67 << 1, 0, 0, 0,
    0, 0, -1, 0.055,
    0, 1, 0, 0,
    0, 0, 0, 1;
    Matrix4d t60 = t70 * t67;

    cout <<"t60 "<<endl  << t60 << endl << endl;

    //pieper

    return pieper_theta2(t60);

}


Matrix4d kinetic(Matrix<double, 6, 1> theta)
{
    Matrix4d t10, t21, t32, t43, t54, t65; //
    t10 << cos(theta(0)), -sin(theta(0)), 0, 0,
    sin(theta(0)), cos(theta(0)), 0, 0,
    0, 0, 1, 0,
    0, 0, 0, 1;
    t21 <<  -sin(theta(1)), -cos(theta(1)), 0, 0,
    0, 0, -1, 0,
    cos(theta(1)), -sin(theta(1)), 0, 0,
    0, 0, 0, 1;
    t32 << cos(theta(2)), -sin(theta(2)), 0, 0.225,
    sin(theta(2)), cos(theta(2)), 0, 0,
    0, 0, 1, 0,
    0, 0, 0, 1;
    t43 << cos(theta(3)), -sin(theta(3)), 0, 0,
    0, 0, -1, -0.2289,
    sin(theta(3)), cos(theta(3)), 0, 0,
    0, 0, 0, 1;
    t54 << sin(theta(4)), cos(theta(4)), 0, 0,
    0, 0, 1, 0,
    cos(theta(4)), -sin(theta(4)), 0, 0,
    0, 0, 0, 1;
    t65 << cos(theta(5)), -sin(theta(5)), 0, 0,
    0, 0, -1, 0,
    sin(theta(5)), cos(theta(5)),0, 0,
    0, 0, 0, 1;
    Matrix4d t76;
    t76 << 1, 0, 0, 0,
    0, 0, 1, 0,
    0, -1, 0, 0.055,
    0, 0, 0, 1;
    //test
    /*Matrix4d t60;
    t60 =   t10 * t21 * t32 * t43 * t54 * t65;
    cout << "kinetic t60" << endl << t60 << endl;*/
    Matrix4d t70 = t10 * t21 * t32 * t43 * t54 * t65 * t76;

    return t70;

}



Matrix<double, 6, 1> pos_pos(Matrix4d t)
{
    MatrixXd pos(6,1);
    pos(0) = t(0,3);
    pos(1) = t(1,3);
    pos(2) = t(2,3);
    pos(4) = atan2(-t(2,0),sqrt(t(0,0) * t(0,0) + t(1,0) * t(1, 0)));
    pos(5) = atan2(t(1,0)/cos(pos(4)),t(0,0)/cos(pos(4)));
    pos(3) = atan2(t(2,1)/cos(pos(4)), t(2,2)/cos(pos(4)));

    return pos;
}

int main(int argc, char ** argv)
{
    Matrix<double, 6, 1> pos0,pos1,pos2;
    MatrixXd joint_ang(6,3);

    //cout << "joint_ang"<< joint_ang << endl;

    double dur = 10;

    MatrixXd estimate(6, 3);

    MatrixXd joint_vel(6, 2);
    MatrixXd joint_acc(6, 2);
    joint_vel << 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0;
    joint_acc << 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0;

   /* joint_vel(3, 1) = 0;
    joint_vel(3, 2) = 0;
    joint_acc(3, 1) = 0;
    joint_acc(3, 2) = 0;
    joint_vel(5, 1) = 0;
    joint_vel(5, 2) = 0;
    joint_acc(5, 1) = 0;
    joint_acc(5, 2) = 0;*/

    //cout << "joint_vel" << endl << joint_vel << endl;
    //cout << "joint_acc" << endl << joint_acc << endl;

    Matrix<double, 6, 6> coe;

    //cout << "coe" << endl << coe << endl;
    

   // cout << "coe" << endl << coe << endl << "coe2" << endl << coe2 << endl << "coe3" << endl <<  coe3 << endl;

    ros::init(argc, argv, "jacob");

    ros::NodeHandle vel_control;

    ros::Publisher vel_pub = vel_control.advertise<std_msgs::Float64MultiArray>("/probot_anno/arm_vel_controller/command", 10);

    int looptimes = 10;
    ros::Rate loop_rate(looptimes);

    int count = -1;
    int flag = 0;
    double interval = 0;

    Matrix<double, 6, 1> joint_velr;
    joint_velr << 0, 0, 0, 0, 0, 0;
    Matrix<double, 6, 1> postemp;
    vector< Matrix<double,6, 1> > traj;
    postemp <<0.28, -0.24, 0.08, 1.57, 0, 0;
    traj.push_back(postemp);
    postemp <<0.26, 0.15, 0.08, 1.57, 0, 0;
    traj.push_back(postemp);
    postemp <<0.2289, 0, 0.454, 1.57, 0, 0;
    traj.push_back(postemp);
    cout << "angle pos"<< endl << postemp(0) << endl;
    
    /*int n = 10;
    for(int i = 1; i <= n; i ++){
        postemp(3) -= 0.785 / n;
        postemp(4) -= 0.785 / n;
        traj.push_back(postemp);
    }
    for(int i = 1; i <= n; i ++){
        postemp(3) += 0.785 / n;
        postemp(4) -= 0.415 / n;
        traj.push_back(postemp);
    }
    for(int i = 1; i <= n; i ++){
        postemp(3) += 0.785 / n;
        postemp(4) += 0.415 / n;
        traj.push_back(postemp);
    }
    for(int i = 1; i <= n; i ++){
        postemp(3) -= 0.785 / n;
        postemp(4) += 0.785 / n;
        traj.push_back(postemp);
    }*/
    


    pos1 = traj.back();
    traj.pop_back();
    pos2 = traj.back();
    traj.pop_back();

    pos1(2) -= 0.284;
    pos2(2) -= 0.284;

    while(ros::ok())
    { 
        std_msgs::Float64MultiArray vel_msg;
        vel_msg.data.push_back(0);
        vel_msg.data.push_back(0);
        vel_msg.data.push_back(0);
        vel_msg.data.push_back(0);
        vel_msg.data.push_back(0);
        vel_msg.data.push_back(0);
        vel_msg.data.at(0) = joint_velr(0);
        vel_msg.data.at(1) = joint_velr(1);
        vel_msg.data.at(2) = joint_velr(2);
        vel_msg.data.at(3) = joint_velr(3);
        vel_msg.data.at(4) = joint_velr(4);
        vel_msg.data.at(5) = joint_velr(5);

        vel_pub.publish(vel_msg);

        if(count <= dur * looptimes && count >= 0){
            interval = count / looptimes;
           for(int i = 0;i <= 5;i ++){
               joint_velr(i) = coe(i, 1) + 2 * coe(i, 2) * interval + 3 * coe(i, 3) * interval * interval + 4 * coe(i, 4) * interval * interval * interval + 5 * coe(i, 5) * interval * interval * interval * interval;
           }
        }else{
            count = 0;
            if(!traj.empty()){
                pos0 = pos1;
                pos1 = pos2;
                pos2 = traj.back();
                traj.pop_back();

                pos2(2) -= 0.284;
                joint_ang.block(0, 0, 6, 1) = revkinetic(pos0);
                joint_ang.block(0, 1, 6, 1) = revkinetic(pos1);
                joint_ang.block(0, 2, 6, 1) = revkinetic(pos2);
                for(int i = 0; i <= 5; i ++){
                    estimate(i, 2) = (joint_ang(i, 2) - joint_ang(i, 0) - 2 * joint_ang(i, 1))/(2 * dur * dur);
                    estimate(i, 1) = (joint_ang(i, 1) - joint_ang(i, 0) - dur * dur * estimate(i, 2)) / dur;
                    estimate(i, 0) = joint_ang(i, 0);
                }
                joint_vel.block(0, 0, 6, 1) = joint_vel.block(0, 1, 6, 1);
                joint_acc.block(0, 0, 6, 1) = joint_acc.block(0, 1, 6, 1);

                for(int i = 0; i <= 5; i ++){
                    joint_vel(i, 1) = estimate(i, 1) + 2 * estimate(i, 2) * dur;
                    joint_acc(i, 1) = 2 * estimate(i, 2);
                }
            }else{
                joint_vel.block(0, 0, 6, 1) = joint_vel.block(0, 1, 6, 1);
                joint_acc.block(0, 0, 6, 1) = joint_acc.block(0, 1, 6, 1);
                joint_vel.block(0, 1, 6, 1) << 0, 0, 0, 0, 0, 0;
                joint_acc.block(0, 1, 6, 1) << 0, 0, 0, 0, 0, 0;
                //dur = 2 * dur;
                
                pos0 = pos1;
                pos1 = pos2;
                flag = 1;
                joint_ang.block(0, 0, 6, 1) = revkinetic(pos0);
                joint_ang.block(0, 1, 6, 1) = revkinetic(pos1);
                
            }
            for(int i = 0;i <= 5;i ++){
                coe(i, 0) = joint_ang(i, 0);
                coe(i, 1) = joint_vel(i, 0);
                coe(i, 2) = joint_acc(i, 0) / 2;
                coe(i, 3) = (20 * joint_ang(i, 1) - 20 * joint_ang(i, 0) - (8 * joint_vel(i, 1) + 12 * joint_vel(i, 0)) * dur - (3 * joint_acc(i, 0) - joint_acc(i, 1)) * dur * dur) / (2 * dur * dur * dur);
                coe(i, 4) = (30 * joint_ang(i, 0) - 30 * joint_ang(i, 1) + (14 * joint_vel(i, 1) + 16 * joint_vel(i, 0)) * dur + (3 * joint_acc(i, 0) - 2 * joint_acc(i, 1)) * dur * dur) / (2 * dur * dur * dur * dur);
                coe(i, 5) = (12 * joint_ang(i, 1) - 12 * joint_ang(i, 0) - (6 * joint_vel(i, 1) + 6 * joint_vel(i, 0)) * dur - (joint_acc(i, 0) - joint_acc(i, 1)) * dur * dur) / (2 * dur * dur * dur * dur * dur);
            }
        }
        count ++;
        if(flag == 1 && count >= dur * looptimes) {
            vel_msg.data.at(0) = 0;
            vel_msg.data.at(1) = 0;
            vel_msg.data.at(2) = 0;
            vel_msg.data.at(3) = 0;
            vel_msg.data.at(4) = 0;
            vel_msg.data.at(5) = 0;
            vel_pub.publish(vel_msg);
            break;
        }
        /*joint(1) = joint(1) + joint_vel(1) / looptimes;
        joint(2) = joint(2) + joint_vel(2) / looptimes;
        joint(3) = joint(3) + joint_vel(3) / looptimes;
        joint(4) = joint(4) + joint_vel(4) / looptimes;
        joint(5) = joint(5) + joint_vel(5) / looptimes;*/
        /*if(count <= 12 * looptimes)
        ROS_INFO("velocity:%f,%f,%f,%f,%f,%f\ncount:%d\n ",vel(0), vel(1), vel(2), vel(3), vel(4), vel(5), count);*/

        loop_rate.sleep();
    }

    return 0;

}

