//1.0 after breakdown
#ifndef PROBOT_GAZEBO_TRAJECTORY_H
#define PROBOT_GAZEBO_TRAJECTORY_H

//#include "Kine_And_Ikine.h"
#include<ros/ros.h>
#include "std_msgs/Float32MultiArray.h"
#include "controller_manager_msgs/SwitchController.h"
#include "controller_manager_msgs/ListControllers.h"
#include <iostream>
#include <cmath>
#include <Eigen/Dense>

//the time between two points
Eigen::MatrixXd q(n,6),dq(n,6),ddq(n,6);
Eigen::MatrixXd qf(n,6),dqf(n,6),ddqf(n,6);
Eigen::MatrixXd a0(n,6),a1(n,6),a2(n,6),a3(n,6),a4(n,6),a5(n,6);

//n points
void Set_Param(void)
{

    q.row(0) << 0, 0, 0, 0, 0, 0;
    q.row(1) << 0.795586, -0.772686,  0.205056,   1.08734,   2.51046, -0.842853;
    q.row(2) << 0.387677,  -1.07517, -0.199884,  0.404374,   2.86768, -0.114923;

    qf.row(0) << 0.795586, -0.772686,  0.205056,   1.08734,   2.51046, -0.842853;
    qf.row(1) << 0.387677,  -1.07517, -0.199884,  0.404374,   2.86768, -0.114923;
    qf.row(2) << -0.387371,  -1.29256, -0.0658126,  -0.394643,    2.94426,  0.0811483;

    dq.row(0) << 0,0,0,0,0,0;
    dq.row(1) << 0.10,-0.10,0.0,0.11,0.30,-0.06;
    dq.row(2) << -0.13,-0.01,-0.01,-0.16,-0.05,0.10;

    dqf.row(0) << 0.10,-0.10,0.0,0.11,0.30,-0.06;
    dqf.row(1) << -0.13,-0.01,-0.01,-0.16,-0.05,0.10;
    dqf.row(2) << 0,0,0,0,0,0;

    ddq.row(0) << 0,0,0,0,0,0;
    ddq.row(1) << -0.02,0.01,-0.01,-0.04,-0.06,0.04;
    ddq.row(2) << 0.02,0,0,0.02,0,-0.02;

    ddqf.row(0) << -0.02,0.01,-0.01,-0.04,-0.06,0.04;
    ddqf.row(1) << 0.02,0,0,0.02,0,-0.02;
    ddqf.row(2) << 0,0,0,0,0,0;

}

void Solve_Route(double tf)
{


    a0 = q;
    a1 = dq;
    a2 = ddq/2;
    a3 = (20*qf-20*q-(8*dqf+12*dq)*tf-(3*ddq - ddqf)*tf*tf)/(2*pow(tf, 3));
    a4 = (30*q-30*qf+(14*dqf+16*dq)*tf +(3*ddq - 2*ddqf)*pow(tf, 2))/(2*pow(tf, 4));
    a5 = (12*qf-12*q-(6*dqf+6*dq)*tf -(ddq-ddqf)*pow(tf, 2))/(2*pow(tf, 5));

    return ;

}
#endif //PROBOT_GAZEBO_TRAJECTORY_H
