#include <string>
#include <ros/ros.h>
#include <iostream>
#include <time.h>
#include <unistd.h>
#include <math.h>
#include "vector"
#include "std_msgs/Float32.h"
#include "std_msgs/Float32MultiArray.h"
#include "controller_manager_msgs/SwitchController.h"
#include "controller_manager_msgs/ListControllers.h"
#include "ikfast.h"
#include "probot_anno_manipulator_ikfast_moveit_plugin.cpp"

#define PI 3.1415926

using namespace ikfast_kinematics_plugin;
using namespace std;

int main(int argc, char** argv)
{

	double a[6][2], b[6][4];
	double t;
	bool ret;
	int i, j;
	ros::init(argc, argv, "ring");
	ros::NodeHandle node_handle;
	ros::AsyncSpinner spinner(1);
	ros::Publisher vel_pub = node_handle.advertise<std_msgs::Float32MultiArray>("speed_chatter", 1000);
	ikfast_kinematics_plugin::IKFastKinematicsPlugin ik;
	ret = ik.IKFastKinematicsPlugin::initialize("robot_description", "manipulator", "base_link", "link_6", 0.001);
	geometry_msgs::Pose target_pose;
	std_msgs::Float32MultiArray init_vel;

	std::vector<geometry_msgs::Pose> pose1, pose2, pose3, pose4;
	std::vector<std::vector<double>> sol_rad1, sol_rad2, sol_rad3, sol_rad4;
	kinematics::KinematicsResult kinematic_result1, kinematic_result2, kinematic_result3, kinematic_result4;
	std::vector<double> seed;

	seed.push_back(0.0);
	seed.push_back(0.0);
	seed.push_back(0.0);
	seed.push_back(0.0);
	seed.push_back(0.0);
	seed.push_back(0.0);

	//B点：
	target_pose.position.x = 0.26;
	target_pose.position.y = 0.15;
	target_pose.position.z = 0.07 - 0.022;
	target_pose.orientation.x = 1.0;

	pose1.push_back(target_pose);

	ret = ik.getPositionIK(pose1, seed, sol_rad1, kinematic_result1, kinematics::KinematicsQueryOptions());

	cout << "sol_rad1: ";
	if (ret)
	{
		std::cout << sol_rad1.size() << " IK solved successfully." << endl;

		for (int q = 0; q < sol_rad1.size(); q++)
		{
			for (int i = 0; i < 6; i++)
			{
				cout << sol_rad1[q][i] << "  ";
			}
			cout << endl;
		}
	}

	//P点：
	target_pose.position.x = 0.27;
	target_pose.position.y = 0.065;
	target_pose.position.z = 0.30 - 0.022;
	target_pose.orientation.x = 1.0;

	pose2.push_back(target_pose);

	ret = ik.getPositionIK(pose2, seed, sol_rad2, kinematic_result2, kinematics::KinematicsQueryOptions());

	cout << "sol_rad2: ";
	if (ret)
	{
		std::cout << sol_rad2.size() << " IK solved successfully." << endl;

		for (int q = 0; q < sol_rad2.size(); q++)
		{
			for (int i = 0; i < 6; i++)
			{
				cout << sol_rad2[q][i] << "  ";
			}
			cout << endl;
		}
	}

	//Q点：
	target_pose.position.x = 0.27;
	target_pose.position.y = -0.15;
	target_pose.position.z = 0.30 - 0.022;
	target_pose.orientation.x = 1.0;

	pose3.push_back(target_pose);

	ret = ik.getPositionIK(pose3, seed, sol_rad3, kinematic_result3, kinematics::KinematicsQueryOptions());

	cout << "sol_rad3: ";
	if (ret)
	{
		std::cout << sol_rad3.size() << " IK solved successfully." << endl;

		for (int q = 0; q < sol_rad3.size(); q++)
		{
			for (int i = 0; i < 6; i++)
			{
				cout << sol_rad3[q][i] << "  ";
			}
			cout << endl;
		}
	}

	//C点：
	target_pose.position.x = 0.28;
	target_pose.position.y = -0.24;
	target_pose.position.z = 0.08 - 0.022;
	target_pose.orientation.x = 1.0;

	pose4.push_back(target_pose);

	ret = ik.getPositionIK(pose4, seed, sol_rad4, kinematic_result4, kinematics::KinematicsQueryOptions());

	cout << "sol_rad4: ";
	if (ret)
	{
		std::cout << sol_rad4.size() << " IK solved successfully." << endl;

		for (int q = 0; q < sol_rad4.size(); q++)
		{
			for (int i = 0; i < 6; i++)
			{
				cout << sol_rad4[q][i] << "  ";
			}
			cout << endl;
		}
	}

	for (i = 0; i < 6; i++)
	{
		a[i][1] = -2 * sol_rad1[0][i] / pow(3, 3);
		a[i][0] = 3 * sol_rad1[0][i] / pow(3, 2);
	}

	for (i = 0; i < 6; i++)
	{
		b[i][3] = -0.0078125 * (sol_rad2[0][i] - sol_rad1[0][i]) + 0.0078125 * (sol_rad3[0][i] - sol_rad1[0][i]) - 0.00376 * (sol_rad4[0][i] - sol_rad1[0][i]);
		b[i][2] = 0.125 * (sol_rad2[0][i] - sol_rad1[0][i]) - 0.109375 * (sol_rad3[0][i] - sol_rad1[0][i]) + 0.04861 * (sol_rad4[0][i] - sol_rad1[0][i]);
		b[i][1] = -0.65625 * (sol_rad2[0][i] - sol_rad1[0][i]) + 0.46875 * (sol_rad3[0][i] - sol_rad1[0][i]) - 0.18634 * (sol_rad4[0][i] - sol_rad1[0][i]);
		b[i][0] = 1.125 * (sol_rad2[0][i] - sol_rad1[0][i]) - 0.5625 * (sol_rad3[0][i] - sol_rad1[0][i]) + 0.20833 * (sol_rad4[0][i] - sol_rad1[0][i]);
	}

	init_vel.data.push_back(0);
	init_vel.data.push_back(0);
	init_vel.data.push_back(0);
	init_vel.data.push_back(0);
	init_vel.data.push_back(0);
	init_vel.data.push_back(0);
	sleep(1);

	ROS_INFO_STREAM("start");
	for (i = 0; i < 30000; i++)
	{
		t = (i + 1) / 10000.0;
		init_vel.data.at(0) = (3 * a[0][1] * pow(t, 2) + 2 * a[0][0] * t) * 30 * 180 / PI;
		init_vel.data.at(1) = (3 * a[1][1] * pow(t, 2) + 2 * a[1][0] * t - 0.0004 * t) * 205 * 180 / (3 * PI);
		init_vel.data.at(2) = (3 * a[2][1] * pow(t, 2) + 2 * a[2][0] * t) * 50 * 180 / PI;
		init_vel.data.at(3) = (3 * a[3][1] * pow(t, 2) + 2 * a[3][0] * t) * 125 * 180 / (2 * PI);
		init_vel.data.at(4) = (3 * a[4][1] * pow(t, 2) + 2 * a[4][0] * t) * 125 * 180 / (2 * PI);
		init_vel.data.at(5) = (3 * a[5][1] * pow(t, 2) + 2 * a[5][0] * t) * 200 * 180 / (9 * PI);
		vel_pub.publish(init_vel);
		usleep(18);
	}

	for (j = 0; j < 8; j++)
	{
		for (i = 0; i < 60000; i++)
		{
			t = (i + 1) / 10000.0;
			init_vel.data.at(0) = (5 * b[0][3] * pow(t, 4) + 4 * b[0][2] * pow(t, 3) + 3 * b[0][1] * pow(t, 2) + 2 * b[0][0] * t) * 30 * 180 / PI;
			init_vel.data.at(1) = (5 * b[1][3] * pow(t, 4) + 4 * b[1][2] * pow(t, 3) + 3 * b[1][1] * pow(t, 2) + 2 * b[1][0] * t + 0.0013 * t) * 205 * 180 / (3 * PI);
			init_vel.data.at(2) = (5 * b[2][3] * pow(t, 4) + 4 * b[2][2] * pow(t, 3) + 3 * b[2][1] * pow(t, 2) + 2 * b[2][0] * t) * 50 * 180 / PI;
			init_vel.data.at(3) = (5 * b[3][3] * pow(t, 4) + 4 * b[3][2] * pow(t, 3) + 3 * b[3][1] * pow(t, 2) + 2 * b[3][0] * t) * 125 * 180 / (2 * PI);
			init_vel.data.at(4) = (5 * b[4][3] * pow(t, 4) + 4 * b[4][2] * pow(t, 3) + 3 * b[4][1] * pow(t, 2) + 2 * b[4][0] * t) * 125 * 180 / (2 * PI);
			init_vel.data.at(5) = (5 * b[5][3] * pow(t, 4) + 4 * b[5][2] * pow(t, 3) + 3 * b[5][1] * pow(t, 2) + 2 * b[5][0] * t) * 200 * 180 / (9 * PI);
			vel_pub.publish(init_vel);
			usleep(18);
		}

		for (i = 0; i < 60000; i++)
		{
			t = 6.0 - i / 10000.0;
			init_vel.data.at(0) = -(5 * b[0][3] * pow(t, 4) + 4 * b[0][2] * pow(t, 3) + 3 * b[0][1] * pow(t, 2) + 2 * b[0][0] * t) * 30 * 180 / PI;
			init_vel.data.at(1) = -(5 * b[1][3] * pow(t, 4) + 4 * b[1][2] * pow(t, 3) + 3 * b[1][1] * pow(t, 2) + 2 * b[1][0] * t + 0.0013 * t) * 205 * 180 / (3 * PI);
			init_vel.data.at(2) = -(5 * b[2][3] * pow(t, 4) + 4 * b[2][2] * pow(t, 3) + 3 * b[2][1] * pow(t, 2) + 2 * b[2][0] * t) * 50 * 180 / PI;
			init_vel.data.at(3) = -(5 * b[3][3] * pow(t, 4) + 4 * b[3][2] * pow(t, 3) + 3 * b[3][1] * pow(t, 2) + 2 * b[3][0] * t) * 125 * 180 / (2 * PI);
			init_vel.data.at(4) = -(5 * b[4][3] * pow(t, 4) + 4 * b[4][2] * pow(t, 3) + 3 * b[4][1] * pow(t, 2) + 2 * b[4][0] * t) * 125 * 180 / (2 * PI);
			init_vel.data.at(5) = -(5 * b[5][3] * pow(t, 4) + 4 * b[5][2] * pow(t, 3) + 3 * b[5][1] * pow(t, 2) + 2 * b[5][0] * t) * 200 * 180 / (9 * PI);
			vel_pub.publish(init_vel);
			usleep(18);
		}
	}

	ROS_INFO_STREAM("end");
	init_vel.data.at(0) = 0.0;
	init_vel.data.at(1) = 0.0;
	init_vel.data.at(2) = 0.0;
	init_vel.data.at(3) = 0.0;
	init_vel.data.at(4) = 0.0;
	init_vel.data.at(5) = 0.0;
	for (i = 0; i < 10000; i++)
	{
		vel_pub.publish(init_vel);
	}
}