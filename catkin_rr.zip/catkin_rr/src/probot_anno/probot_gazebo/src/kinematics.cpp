#include <string>
#include <ros/ros.h>
#include <iostream>
#include <time.h>
#include <stdlib.h>
#include "vector"
#include "std_msgs/Float32.h"
#include "std_msgs/Float64MultiArray.h"
#include "controller_manager_msgs/SwitchController.h"
#include "controller_manager_msgs/ListControllers.h"
#include "ikfast.h"
#include "probot_anno_manipulator_ikfast_moveit_plugin.cpp"

#define s(r) sin(r)
#define c(r) cos(r)

using namespace ikfast_kinematics_plugin;
double *pos(double rad[]);

int main(int argc, char **argv)
{

    bool ret;
    int i;
    double rad[6];
    double *p;
    ros::init(argc, argv, "kinematics");
    ros::NodeHandle node_handle;
    ros::AsyncSpinner spinner(1);
    ros::Publisher pos_pub = node_handle.advertise<std_msgs::Float64MultiArray>("/probot_anno/arm_pos_controller/command", 100);
    ikfast_kinematics_plugin::IKFastKinematicsPlugin ik;
    ret = ik.IKFastKinematicsPlugin::initialize("robot_description", "manipulator", "base_link", "link_6", 0.001);
    geometry_msgs::Pose target_pose;
    std_msgs::Float64MultiArray init_fkpos, init_ikpos;

    ROS_INFO_STREAM("start");

    //正运动学：
    ROS_INFO_STREAM("fk:");

    init_fkpos.data.push_back(0);
    init_fkpos.data.push_back(0);
    init_fkpos.data.push_back(0);
    init_fkpos.data.push_back(0);
    init_fkpos.data.push_back(0);
    init_fkpos.data.push_back(0);
    sleep(1);

    //第一组关节角度
    init_fkpos.data.at(0) = 0.9270;
    init_fkpos.data.at(1) = -0.6870;
    init_fkpos.data.at(2) = -0.3960;
    init_fkpos.data.at(3) = 0.0001;
    init_fkpos.data.at(4) = 1.0830;
    init_fkpos.data.at(5) = 0.9270;

    pos_pub.publish(init_fkpos);
    ROS_INFO_STREAM("published:fk1");

    for (i = 0; i < 6; i++)
    {
        rad[i] = init_fkpos.data.at(i);
    }
    p = pos(rad);
    cout << "theoretical pos:" << endl;
    cout << "x = " << p[0] << ", ";
    cout << "y = " << p[1] << ", ";
    cout << "z = " << p[2] << endl;
    cout << "roll = " << p[3] << ", ";
    cout << "pitch = " << p[4] << ", ";
    cout << "yaw = " << p[5] << endl;

    sleep(10);

    init_fkpos.data.at(0) = 0.0;
    init_fkpos.data.at(1) = 0.0;
    init_fkpos.data.at(2) = 0.0;
    init_fkpos.data.at(3) = 0.0;
    init_fkpos.data.at(4) = 0.0;
    init_fkpos.data.at(5) = 0.0;
    pos_pub.publish(init_fkpos);
    ROS_INFO_STREAM("reset");
    sleep(2);

    //第二组关节角度
    init_fkpos.data.at(0) = 0.3220;
    init_fkpos.data.at(1) = -0.8550;
    init_fkpos.data.at(2) = -0.0210;
    init_fkpos.data.at(3) = 0.0001;
    init_fkpos.data.at(4) = 0.8770;
    init_fkpos.data.at(5) = 0.3220;

    pos_pub.publish(init_fkpos);
    ROS_INFO_STREAM("published:fk2");

    for (i = 0; i < 6; i++)
    {
        rad[i] = init_fkpos.data.at(i);
    }
    p = pos(rad);
    cout << "theoretical pos:" << endl;
    cout << "x = " << p[0] << ", ";
    cout << "y = " << p[1] << ", ";
    cout << "z = " << p[2] << endl;
    cout << "roll = " << p[3] << ", ";
    cout << "pitch = " << p[4] << ", ";
    cout << "yaw = " << p[5] << endl;

    sleep(10);

    init_fkpos.data.at(0) = 0.0;
    init_fkpos.data.at(1) = 0.0;
    init_fkpos.data.at(2) = 0.0;
    init_fkpos.data.at(3) = 0.0;
    init_fkpos.data.at(4) = 0.0;
    init_fkpos.data.at(5) = 0.0;
    pos_pub.publish(init_fkpos);
    ROS_INFO_STREAM("reset");
    sleep(2);

    //第三组关节角度
    init_fkpos.data.at(0) = -0.3220;
    init_fkpos.data.at(1) = -0.6360;
    init_fkpos.data.at(2) = -0.0110;
    init_fkpos.data.at(3) = 0.0001;
    init_fkpos.data.at(4) = 0.6470;
    init_fkpos.data.at(5) = -0.3220;

    pos_pub.publish(init_fkpos);
    ROS_INFO_STREAM("published:fk3");

    for (i = 0; i < 6; i++)
    {
        rad[i] = init_fkpos.data.at(i);
    }
    p = pos(rad);
    cout << "theoretical pos:" << endl;
    cout << "x = " << p[0] << ", ";
    cout << "y = " << p[1] << ", ";
    cout << "z = " << p[2] << endl;
    cout << "roll = " << p[3] << ", ";
    cout << "pitch = " << p[4] << ", ";
    cout << "yaw = " << p[5] << endl;

    sleep(10);

    init_fkpos.data.at(0) = 0.0;
    init_fkpos.data.at(1) = 0.0;
    init_fkpos.data.at(2) = 0.0;
    init_fkpos.data.at(3) = 0.0;
    init_fkpos.data.at(4) = 0.0;
    init_fkpos.data.at(5) = 0.0;
    pos_pub.publish(init_fkpos);
    ROS_INFO_STREAM("reset");
    sleep(2);

    //逆运动学:
    ROS_INFO_STREAM("ik:");

    std::vector<geometry_msgs::Pose> pose1, pose2, pose3;
    std::vector<std::vector<double>> sol_rad1, sol_rad2, sol_rad3;
    kinematics::KinematicsResult kinematic_result1, kinematic_result2, kinematic_result3;
    std::vector<double> seed;

    init_ikpos.data.push_back(0);
    init_ikpos.data.push_back(0);
    init_ikpos.data.push_back(0);
    init_ikpos.data.push_back(0);
    init_ikpos.data.push_back(0);
    init_ikpos.data.push_back(0);

    seed.push_back(0.0);
    seed.push_back(0.0);
    seed.push_back(0.0);
    seed.push_back(0.0);
    seed.push_back(0.0);
    seed.push_back(0.0);
    sleep(1);

    //第一组末端位姿解算:

    target_pose.position.x = 0.2;
    target_pose.position.y = 0.2;
    target_pose.position.z = 0.2007 - 0.022;
    target_pose.orientation.w = 0.5;
    target_pose.orientation.x = 0.5;
    target_pose.orientation.y = 0.5;
    target_pose.orientation.z = 0.5;

    pose1.push_back(target_pose);

    ret = ik.getPositionIK(pose1, seed, sol_rad1, kinematic_result1, kinematics::KinematicsQueryOptions());

    if (ret)
    {
        std::cout << sol_rad1.size() << " IK solved successfully." << endl;

        for (int q = 0; q < sol_rad1.size(); q++)
        {
            sol_rad1[q][5] += 1.5708;
            for (int i = 0; i < 6; i++)
            {
                cout << sol_rad1[q][i] << " ";
            }
            cout << endl;
        }
    }

    init_ikpos.data.at(0) = sol_rad1[0][0];
    init_ikpos.data.at(1) = sol_rad1[0][1];
    init_ikpos.data.at(2) = sol_rad1[0][2];
    init_ikpos.data.at(3) = sol_rad1[0][3];
    init_ikpos.data.at(4) = sol_rad1[0][4];
    init_ikpos.data.at(5) = sol_rad1[0][5];
    pos_pub.publish(init_ikpos);
    ROS_INFO_STREAM("published:ik1");
    sleep(10);

    init_ikpos.data.at(0) = 0.0;
    init_ikpos.data.at(1) = 0.0;
    init_ikpos.data.at(2) = 0.0;
    init_ikpos.data.at(3) = 0.0;
    init_ikpos.data.at(4) = 0.0;
    init_ikpos.data.at(5) = 0.0;
    pos_pub.publish(init_ikpos);
    ROS_INFO_STREAM("reset");
    sleep(2);

    //第二组末端位姿解算：

    target_pose.position.x = 0.15;
    target_pose.position.y = 0.2;
    target_pose.position.z = 0.2007 - 0.022;
    target_pose.orientation.w = 0.5;
    target_pose.orientation.x = 0.5;
    target_pose.orientation.y = 0.5;
    target_pose.orientation.z = -0.5;

    pose2.push_back(target_pose);

    ret = ik.getPositionIK(pose2, seed, sol_rad2, kinematic_result2, kinematics::KinematicsQueryOptions());

    if (ret)
    {
        std::cout << sol_rad2.size() << " IK solved successfully." << endl;

        for (int q = 0; q < sol_rad2.size(); q++)
        {
            sol_rad2[q][5] += 1.5708;
            for (int i = 0; i < 6; i++)
            {
                cout << sol_rad2[q][i] << " ";
            }
            cout << endl;
        }
    }

    init_ikpos.data.at(0) = sol_rad2[0][0];
    init_ikpos.data.at(1) = sol_rad2[0][1];
    init_ikpos.data.at(2) = sol_rad2[0][2];
    init_ikpos.data.at(3) = sol_rad2[0][3];
    init_ikpos.data.at(4) = sol_rad2[0][4];
    init_ikpos.data.at(5) = sol_rad2[0][5];
    pos_pub.publish(init_ikpos);

    ROS_INFO_STREAM("published:ik2");
    sleep(10);

    init_ikpos.data.at(0) = 0.0;
    init_ikpos.data.at(1) = 0.0;
    init_ikpos.data.at(2) = 0.0;
    init_ikpos.data.at(3) = 0.0;
    init_ikpos.data.at(4) = 0.0;
    init_ikpos.data.at(5) = 0.0;
    pos_pub.publish(init_ikpos);
    ROS_INFO_STREAM("reset");
    sleep(2);

    //第三组末端位姿解算：

    target_pose.position.x = 0.3;
    target_pose.position.y = 0.0;
    target_pose.position.z = 0.122 - 0.022;
    target_pose.orientation.w = 0.0;
    target_pose.orientation.x = 1.0;
    target_pose.orientation.y = 0.0;
    target_pose.orientation.z = 0.0;

    pose3.push_back(target_pose);

    ret = ik.getPositionIK(pose3, seed, sol_rad3, kinematic_result3, kinematics::KinematicsQueryOptions());

    if (ret)
    {
        std::cout << sol_rad3.size() << " IK solved successfully." << endl;

        for (int q = 0; q < sol_rad3.size(); q++)
        {
            for (int i = 0; i < 6; i++)
            {
                cout << sol_rad3[q][i] << " ";
            }
            cout << endl;
        }
    }

    init_ikpos.data.at(0) = sol_rad3[0][0];
    init_ikpos.data.at(1) = sol_rad3[0][1];
    init_ikpos.data.at(2) = sol_rad3[0][2];
    init_ikpos.data.at(3) = sol_rad3[0][3];
    init_ikpos.data.at(4) = sol_rad3[0][4];
    init_ikpos.data.at(5) = sol_rad3[0][5];
    pos_pub.publish(init_ikpos);
    ROS_INFO_STREAM("published:ik3");
    sleep(10);

    init_ikpos.data.at(0) = 0.0;
    init_ikpos.data.at(1) = 0.0;
    init_ikpos.data.at(2) = 0.0;
    init_ikpos.data.at(3) = 0.0;
    init_ikpos.data.at(4) = 0.0;
    init_ikpos.data.at(5) = 0.0;
    pos_pub.publish(init_ikpos);
    ROS_INFO_STREAM("reset");
    sleep(1);
}

double *pos(double rad[])
{
    double *O5, *O6;
    double r1, r2, r3, r4, r5, r6;
    r1 = rad[0];
    r2 = rad[1];
    r3 = rad[2];
    r4 = rad[3];
    r5 = rad[4];
    r6 = rad[5];
    O5 = (double *)malloc(sizeof(double) * 3);
    O6 = (double *)malloc(sizeof(double) * 6);

    O5[0] = -0.225 * c(r1) * s(r2) + 0.2289 * c(r1) * (c(r2) * c(r3) - s(r2) * s(r3));
    O5[1] = -0.225 * s(r1) * s(r2) + 0.2289 * s(r1) * (c(r2) * c(r3) - s(r2) * s(r3));
    O5[2] = 0.284 + 0.225 * c(r2) + 0.2289 * (s(r2) * c(r3) + c(r2) * s(r3));

    O6[0] = O5[0] + 0.055 * c(r1) * c(r2) * (c(r3) * s(r5) + s(r3) * c(r4) * c(r5)) - 0.055 * c(r1) * s(r2) * (s(r3) * s(r5) - c(r3) * c(r4) * c(r5)) - 0.055 * s(r1) * s(r4) * c(r5);
    O6[1] = O5[1] + 0.055 * s(r1) * c(r2) * (c(r3) * s(r5) + s(r3) * c(r4) * c(r5)) - 0.055 * s(r1) * s(r2) * (s(r3) * c(r5) - c(r3) * c(r4) * c(r5)) + 0.055 * c(r1) * s(r4) * c(r5);
    O6[2] = O5[2] + 0.055 * s(r2) * (c(r3) * s(r5) + s(r3) * c(r4) * c(r5)) + 0.055 * c(r2) * (s(r3) * s(r5) - c(r3) * c(r4) * c(r5));
    O6[3] = 1.57 + r4;
    O6[4] = -r2 - r3 - r5;
    O6[5] = r1 - r6;
    return O6;
}