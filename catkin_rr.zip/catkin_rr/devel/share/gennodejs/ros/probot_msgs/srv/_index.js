
"use strict";

let HeartbeatSrv = require('./HeartbeatSrv.js')

module.exports = {
  HeartbeatSrv: HeartbeatSrv,
};
